import "dotenv/config";
import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import Razorpay from "razorpay";
import { Resend } from "resend";
import twilio from "twilio";
import rateLimit from "express-rate-limit";
import { db } from "./src/db/db.ts";
import { tasks as tasksTable, applications as applicationsTable, users as usersTable, notifications as notificationsTable } from "./src/db/schema.ts";
import { eq, and } from "drizzle-orm";
import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";

// Twilio setup
const twilioClient = (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN)
  ? twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN)
  : null;
const twilioPhoneNumber = process.env.TWILIO_PHONE_NUMBER;

async function seedAdmin() {
  try {
    const adminIdentifier = "admin@internloop.com";
    const existing = await db.select().from(usersTable).where(eq(usersTable.identifier, adminIdentifier)).limit(1);
    if (existing.length === 0) {
      const hashedPassword = await bcrypt.hash("admin123", 10);
      await db.insert(usersTable).values({
        identifier: adminIdentifier,
        password: hashedPassword,
        role: "admin"
      });
      console.log("Seeded default admin account");
    }

    const pendingPubs = await db.select().from(usersTable).where(eq(usersTable.role, 'pending_publisher')).limit(1);
    if (pendingPubs.length === 0) {
      const pHash = await bcrypt.hash("password123", 10);
      await db.insert(usersTable).values({
        identifier: "new.publisher@internloop.com",
        password: pHash,
        role: "pending_publisher"
      });
    }

  } catch (e) {
    console.error("Failed to seed admin/demo", e);
  }
}

async function startServer() {
  await seedAdmin();
  const app = express();
  const PORT = 3000;

  app.set("trust proxy", 1); // Trust first proxy (Cloud Run / Nginx)

  // Global Rate Limiter: Max 100 requests per 15 minutes per IP
  const globalLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 5000,
    message: { error: "Too many requests from this IP, please try again after 15 minutes" }
  });
  app.use(globalLimiter);

  // Authentication Rate Limiter: Max 10 requests per 15 minutes per IP for /api/auth
  const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 10,
    message: { error: "Too many authentication attempts, please try again after 15 minutes" }
  });
  app.use("/api/auth", authLimiter);

  app.use(express.json());

  const authenticateToken = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    
    if (token == null) return res.status(401).json({ error: "Unauthorized" });

    const jwtSecret = process.env.JWT_SECRET || "fallback_secret_key_change_me_in_production";
    jwt.verify(token, jwtSecret, (err: any, user: any) => {
      if (err) return res.status(403).json({ error: "Forbidden" });
      (req as any).user = user;
      next();
    });
  };

  // Wait to initialize lazily, because the key might be missing
  let ai: GoogleGenAI | null = null;
  function getGeminiClient() {
    if (!ai) {
      const key = process.env.GEMINI_API_KEY;
      if (!key) {
        throw new Error('GEMINI_API_KEY environment variable is required');
      }
      ai = new GoogleGenAI({ apiKey: key, httpOptions: { headers: { 'User-Agent': 'aistudio-build' } } });
    }
    return ai;
  }

  let razorpayClient: Razorpay | null = null;
  function getRazorpayClient() {
    if (!razorpayClient) {
      const key_id = process.env.RAZORPAY_KEY_ID;
      const key_secret = process.env.RAZORPAY_KEY_SECRET;
      
      if (!key_id || !key_secret) {
        throw new Error('RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET environment variables are required');
      }
      
      razorpayClient = new Razorpay({
        key_id,
        key_secret,
      });
    }
    return razorpayClient;
  }

  // --- In-Memory Database for Platform Ecosystem ---
  interface Task {
    id: string;
    title: string;
    reward: number;
    description: string;
    status: 'open' | 'closed';
    publisher: string;
    createdAt: string;
  }

  interface Application {
    id: string;
    taskId: string;
    taskTitle: string;
    intern: string; // email/name
    status: 'applied' | 'evaluating_ai' | 'pending_human' | 'approved' | 'rejected';
    aiScore?: number | null;
    aiFeedback?: string | null;
    submittedAt?: string | null;
  }

  // --- Core Ecosystem Endpoints ---

  // Tasks Endpoints
  app.get("/api/tasks", authenticateToken, async (req, res) => {
    try {
      const dbTasks = await db.select().from(tasksTable);
      res.json(dbTasks.map(t => ({ ...t, id: t.id.toString() })));
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch tasks" });
    }
  });

  app.post("/api/tasks", authenticateToken, async (req, res) => {
    const { title, reward, description, publisher } = req.body;
    if (!title || !reward || !description) return res.status(400).json({ error: "Missing required fields" });
    
    try {
       const [newTask] = await db.insert(tasksTable).values({
         title,
         reward: Number(reward),
         description,
         publisher: publisher || "Unknown Publisher",
         status: "open",
       }).returning();

       // Send project invitation to all users (for demo)
       try {
         const users = await db.select().from(usersTable);
         const notifications = users.map(u => ({
           userId: u.id,
           message: `New project invitation: '${title}' from ${publisher || "a Publisher"}.`,
           type: 'invitation'
         }));
         if (notifications.length > 0) {
           await db.insert(notificationsTable).values(notifications);
         }
       } catch (e) {
         console.error("Failed to insert task notifications", e);
       }

       res.json({ success: true, task: { ...newTask, id: newTask.id.toString() } });
    } catch (error) {
       res.status(500).json({ error: "Failed to create task" });
    }
  });

  // Applications Endpoints
  app.get("/api/applications", authenticateToken, async (req, res) => {
    try {
      const dbApplications = await db.select().from(applicationsTable);
      res.json(dbApplications.map(a => ({ ...a, id: a.id.toString(), taskId: a.taskId.toString() })));
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch applications" });
    }
  });

  app.post("/api/applications/apply", authenticateToken, async (req, res) => {
    const { taskId, intern } = req.body;
    try {
      const task = await db.select().from(tasksTable).where(eq(tasksTable.id, parseInt(taskId))).limit(1);
      if (!task.length) return res.status(404).json({ error: "Task not found" });
      
      const existing = await db.select().from(applicationsTable).where(and(eq(applicationsTable.taskId, parseInt(taskId)), eq(applicationsTable.intern, intern))).limit(1);
      if (existing.length) return res.status(400).json({ error: "Already applied" });

      const [newApp] = await db.insert(applicationsTable).values({
        taskId: parseInt(taskId),
        taskTitle: task[0].title,
        intern: intern || "Unknown Intern",
        status: 'applied'
      }).returning();
      res.json({ success: true, application: { ...newApp, id: newApp.id.toString(), taskId: newApp.taskId.toString() } });
    } catch (error) {
      res.status(500).json({ error: "Failed to apply" });
    }
  });

  app.post("/api/applications/submit", authenticateToken, async (req, res) => {
    const { taskId, intern, proofUrl, notes } = req.body;
    try {
      const applications = await db.select().from(applicationsTable).where(and(eq(applicationsTable.taskId, parseInt(taskId)), eq(applicationsTable.intern, intern))).limit(1);
      if (!applications.length) return res.status(404).json({ error: "Application not found" });
      
      const application = applications[0];
      
      const [updatedApp] = await db.update(applicationsTable).set({ 
        status: "evaluating_ai",
        submittedAt: new Date(),
        proofUrl: proofUrl || null,
        notes: notes || null
      }).where(eq(applicationsTable.id, application.id)).returning();
      
      // Simulate AI eval delay
      setTimeout(async () => {
        try {
          await db.update(applicationsTable).set({
            status: "pending_human",
            aiScore: Math.floor(Math.random() * 20) + 75,
            aiFeedback: "AI automated evaluation complete. Code looks functional. Awaiting final human verification."
          }).where(eq(applicationsTable.id, application.id));
        } catch (e) {
             console.error("Async eval update failed", e);
        }
      }, 3000);

      res.json({ success: true, application: { ...updatedApp, id: updatedApp.id.toString(), taskId: updatedApp.taskId.toString() } });
    } catch (error) {
      res.status(500).json({ error: "Failed to submit" });
    }
  });

  app.post("/api/applications/evaluate", authenticateToken, async (req, res) => {
    const { applicationId, action } = req.body;
    try {
      const applications = await db.select().from(applicationsTable).where(eq(applicationsTable.id, parseInt(applicationId))).limit(1);
      if (!applications.length) return res.status(404).json({ error: "Application not found" });

      let newStatus = applications[0].status;
      if (action === 'approve') {
         newStatus = 'approved';
      } else if (action === 'reject') {
         newStatus = 'rejected';
      } else {
         return res.status(400).json({ error: "Invalid action" });
      }

      const [updatedApp] = await db.update(applicationsTable).set({ status: newStatus }).where(eq(applicationsTable.id, parseInt(applicationId))).returning();
      
      // Attempt to send a notification to the intern
      try {
        const internEmail = updatedApp.intern;
        const internUsers = await db.select().from(usersTable).where(eq(usersTable.identifier, internEmail)).limit(1);
        if (internUsers.length > 0) {
           await db.insert(notificationsTable).values({
             userId: internUsers[0].id,
             message: `Your application for '${updatedApp.taskTitle}' was ${action === 'approve' ? 'approved' : 'rejected'}.`,
             type: 'evaluation'
           });
        }
      } catch (e) {
        console.error("Failed to insert notification", e);
      }

      res.json({ success: true, application: { ...updatedApp, id: updatedApp.id.toString(), taskId: updatedApp.taskId.toString() } });
    } catch (error) {
      res.status(500).json({ error: "Failed to evaluate" });
    }
  });

  // Admin Metrics
  app.get("/api/admin/users", authenticateToken, async (req, res) => {
    try {
      if ((req as any).user.role !== 'admin') return res.status(403).json({ error: "Forbidden" });
      const users = await db.select().from(usersTable);
      const sanitized = users.map(u => {
        const { password, ...safe } = u;
        return safe;
      });
      res.json(sanitized);
    } catch(e) {
      res.status(500).json({ error: "Failed to fetch users" });
    }
  });

  app.get("/api/admin/disputes", authenticateToken, async (req, res) => {
    try {
      if ((req as any).user.role !== 'admin') return res.status(403).json({ error: "Forbidden" });
      // Simulated disputes for the demo
      res.json([
        { id: "dsp_1", type: "Task Rejection", description: "Intern disputes task evaluation", status: "open", user: "pritam@internloop.com", date: new Date().toISOString() },
        { id: "dsp_2", type: "Payment Delay", description: "Publisher payment not reflected", status: "investigating", user: "amazon@internloop.com", date: new Date(Date.now() - 86400000).toISOString() },
      ]);
    } catch(e) {
      res.status(500).json({ error: "Failed to fetch disputes" });
    }
  });

  app.get("/api/admin/metrics", authenticateToken, async (req, res) => {
    try {
      if ((req as any).user.role !== 'admin') {
         return res.status(403).json({ error: "Forbidden: Admin privileges required" });
      }

      const allTasks = await db.select().from(tasksTable);
      const allApps = await db.select().from(applicationsTable);

      const totalUsers = 8245; // Static
      const activePublishers = new Set(allTasks.map(t => t.publisher)).size + 140; // Combine dynamic + base
      const totalVolume = allApps.filter(a => a.status === 'approved').reduce((acc, app) => {
          const task = allTasks.find(t => t.id === app.taskId);
          return acc + (task ? task.reward : 0);
      }, 2400000); // 2.4M base
      
      res.json({
          totalUsers,
          activePublishers,
          totalVolume,
          openDisputes: 4,
          totalTasks: allTasks.length,
          totalApplications: allApps.length
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch metrics" });
    }
  });

  // Auth Endpoints (Secure OTP)
  // Store in memory for demo. In production, use DB/PostgreSQL/Redis.
  interface OtpData {
    otp: string;
    expiresAt: number;
    attempts: number;
  }
  const otpStore = new Map<string, OtpData>();
  const rateLimitMap = new Map<string, number>();

  app.post('/api/auth/signup', async (req, res) => {
    try {
      let { identifier, password } = req.body;
      if (!identifier || !password) return res.status(400).json({ error: "Identifier and password are required" });
      
      identifier = identifier.trim().toLowerCase();
      
      const existingUser = await db.select().from(usersTable).where(eq(usersTable.identifier, identifier)).limit(1);
      if (existingUser.length > 0) {
        return res.status(400).json({ error: "Account already exists, please login." });
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      await db.insert(usersTable).values({
        identifier,
        password: hashedPassword,
        role: "user" // Default role
      });

      const jwtSecret = process.env.JWT_SECRET || "fallback_secret_key_change_me_in_production";
      const token = jwt.sign({ identifier, role: "user" }, jwtSecret, { expiresIn: '7d' });
      res.json({ success: true, token });
    } catch (e: any) {
      console.error("Signup Error:", e);
      res.status(500).json({ error: "Failed to create account" });
    }
  });

  app.post('/api/auth/login', async (req, res) => {
    try {
      let { identifier, password } = req.body;
      if (!identifier || !password) return res.status(400).json({ error: "Identifier and password are required" });
      
      identifier = identifier.trim().toLowerCase();
      const userResult = await db.select().from(usersTable).where(eq(usersTable.identifier, identifier)).limit(1);
      if (userResult.length === 0) {
        return res.status(400).json({ error: "Invalid credentials" });
      }

      const user = userResult[0];
      if (!user.password) {
         return res.status(400).json({ error: "This account doesn't have a password set. Please use forgot password." });
      }

      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
         return res.status(400).json({ error: "Invalid credentials" });
      }

      const jwtSecret = process.env.JWT_SECRET || "fallback_secret_key_change_me_in_production";
      const token = jwt.sign({ identifier: user.identifier, role: user.role, id: user.id }, jwtSecret, { expiresIn: '7d' });
      res.json({ success: true, token });
    } catch (e: any) {
      console.error("Login Error:", e);
      res.status(500).json({ error: "Failed to login" });
    }
  });

  app.get('/api/me', authenticateToken, async (req, res) => {
     try {
       const userIdentifier = (req as any).user.identifier;
       const userResult = await db.select().from(usersTable).where(eq(usersTable.identifier, userIdentifier)).limit(1);
       if (userResult.length > 0) {
         const { password, ...safeUser } = userResult[0];
         res.json({ user: safeUser });
       } else {
         res.status(404).json({ error: "User not found" });
       }
     } catch (e) {
       res.status(500).json({ error: "Failed to fetch user profile" });
     }
  });

  app.post('/api/users/role', authenticateToken, async (req, res) => {
    try {
      const userIdentifier = (req as any).user.identifier;
      let { role } = req.body;
      
      // If applying as publisher, put them in pending state
      if (role === 'publisher') {
         role = 'pending_publisher';
      }
      
      await db.update(usersTable).set({ role }).where(eq(usersTable.identifier, userIdentifier));
      res.json({ success: true, role });
    } catch(e) {
      res.status(500).json({ error: "Failed to update role" });
    }
  });

  app.get('/api/admin/pending-publishers', authenticateToken, async (req, res) => {
    try {
      if ((req as any).user.role !== 'admin') return res.status(403).json({ error: "Forbidden" });
      const pending = await db.select().from(usersTable).where(eq(usersTable.role, 'pending_publisher'));
      
      const sanitized = pending.map(p => {
        const { password, ...safe } = p;
        return safe;
      });
      res.json(sanitized);
    } catch(e) {
      res.status(500).json({ error: "Failed to fetch pending publishers" });
    }
  });

  app.post('/api/admin/approve-publisher', authenticateToken, async (req, res) => {
    try {
      if ((req as any).user.role !== 'admin') return res.status(403).json({ error: "Forbidden" });
      const { id, action } = req.body;
      const newRole = action === 'approve' ? 'publisher' : 'user';
      
      await db.update(usersTable).set({ role: newRole }).where(eq(usersTable.id, parseInt(id)));
      
      // Notify user
      await db.insert(notificationsTable).values({
         userId: parseInt(id),
         message: `Your publisher registration was ${action === 'approve' ? 'approved' : 'rejected'}.`,
         type: 'evaluation'
      });

      res.json({ success: true });
    } catch(e) {
      res.status(500).json({ error: "Failed to process publisher" });
    }
  });

  app.post('/api/auth/forgot-password', async (req, res) => {
     try {
       let { identifier } = req.body;
       if (!identifier) return res.status(400).json({ error: "Identifier is required" });
       
       identifier = identifier.trim().toLowerCase();
       const userResult = await db.select().from(usersTable).where(eq(usersTable.identifier, identifier)).limit(1);
       
       if (userResult.length === 0) {
          return res.status(400).json({ error: "No account found with that identifier" });
       }

       // For demo purposes, we will reset the password directly to "password123" if requested
       // In a real app, we'd send an OTP using the send-otp logic below
       const hashedPassword = await bcrypt.hash("password123", 10);
       await db.update(usersTable).set({ password: hashedPassword }).where(eq(usersTable.identifier, identifier));

       res.json({ success: true, message: "Your temporary password has been reset to: password123" });
     } catch(e) {
       res.status(500).json({ error: "Failed to process forgot password" });
     }
  });
  app.get("/api/notifications", authenticateToken, async (req, res) => {
    try {
      const userIdentifier = (req as any).user.identifier;
      const userResult = await db.select().from(usersTable).where(eq(usersTable.identifier, userIdentifier)).limit(1);
      if (userResult.length === 0) return res.status(404).json({ error: "User not found" });

      const userNotifications = await db.select().from(notificationsTable).where(eq(notificationsTable.userId, userResult[0].id));
      res.json(userNotifications);
    } catch (e) {
      res.status(500).json({ error: "Failed to fetch notifications" });
    }
  });

  app.post("/api/notifications/mark-read", authenticateToken, async (req, res) => {
    try {
      const userIdentifier = (req as any).user.identifier;
      const userResult = await db.select().from(usersTable).where(eq(usersTable.identifier, userIdentifier)).limit(1);
      if (userResult.length === 0) return res.status(404).json({ error: "User not found" });

      await db.update(notificationsTable).set({ isRead: 1 }).where(eq(notificationsTable.userId, userResult[0].id));
      res.json({ success: true });
    } catch (e) {
      res.status(500).json({ error: "Failed to update notifications" });
    }
  });

  // Chat endpoint
  app.post("/api/chat", authenticateToken, async (req, res) => {
    try {
      const { messages } = req.body; // Expecting { role: 'user' | 'model', parts: [{text}]}[] logic
      if (!messages || !Array.isArray(messages)) {
        return res.status(400).json({ error: "Invalid messages format" });
      }

      const client = getGeminiClient();
      
      const lastMessage = messages[messages.length - 1];
      const previousMessages = messages.slice(0, messages.length - 1);

      // Simple implementation: send the entire conversation history context as contents
      const response = await client.models.generateContent({
        model: "gemini-2.5-flash",
        contents: messages,
        config: {
          systemInstruction: "You are a helpful assistant for InternLoop, a task bounty platform. You can answer questions about finding tasks, evaluations, WorkScore (reputation system), and how payments work.",
        }
      });
      
      res.json({ text: response.text });
    } catch (e: any) {
      console.error("Chat Error:", e);
      res.status(500).json({ error: e.message || "Internal server error" });
    }
  });

  // Razorpay Order creation endpoint
  app.post("/api/create-order", authenticateToken, async (req, res) => {
    try {
      const { amount } = req.body;
      const razorpay = getRazorpayClient();

      if (!amount) {
        return res.status(400).json({ error: "Amount is required" });
      }

      // amount is in smallest currency unit (paise for INR)
      const options = {
        amount: Math.round(amount),
        currency: "INR",
        receipt: `receipt_order_${Date.now()}`
      };
      
      const order = await razorpay.orders.create(options);
      
      res.json({ orderId: order.id, amount: order.amount, currency: order.currency });
    } catch (e: any) {
      console.error("Razorpay Error:", e);
      res.status(500).json({ error: e.message || "Failed to create order" });
    }
  });


  // Razorpay withdraw endpoint (simulated payouts for demo)
  app.post("/api/withdraw", authenticateToken, async (req, res) => {
    try {
      const { amount, method, destination } = req.body;
      
      if (!amount || !method || !destination) {
        return res.status(400).json({ error: "Amount, method, and destination are required" });
      }

      // Simulate a withdrawal process via RazorpayX or standard payout
      // In a real application, you'd use razorpay.payouts.create(...)
      
      setTimeout(() => {
        res.json({ 
          success: true, 
          message: "Withdrawal processed successfully", 
          payoutId: `pout_${Date.now()}`,
          amount,
          status: "processing"
        });
      }, 1500); // Simulate network/processing delay

    } catch (e: any) {
      console.error("Withdraw Error:", e);
      res.status(500).json({ error: e.message || "Failed to process withdrawal" });
    }
  });

  // Mock transactions history endpoint
  app.get("/api/transactions", authenticateToken, async (req, res) => {
    try {
      // Return a set of dummy transactions showing deposits & dummy withdrawals
      const transactions = [
        { id: "txn_12345", type: "deposit", amount: 5000, status: "success", date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 1).toISOString(), method: "UPI" },
        { id: "txn_12346", type: "withdrawal", amount: 1550, status: "success", date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString(), method: "Bank Transfer" },
        { id: "txn_12347", type: "deposit", amount: 10000, status: "success", date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 10).toISOString(), method: "Credit Card" },
        { id: "txn_12348", type: "withdrawal", amount: 2000, status: "processing", date: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(), method: "UPI" },
      ];
      
      res.json({ transactions });
    } catch (e: any) {
      console.error("Transactions Error:", e);
      res.status(500).json({ error: e.message || "Failed to fetch transactions" });
    }
  });

  // --- Vite Middleware ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
