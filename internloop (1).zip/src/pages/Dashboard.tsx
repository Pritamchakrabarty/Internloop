import React, { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  Briefcase, 
  Trophy, 
  Wallet, 
  UserCircle, 
  Search, 
  Bell, 
  Settings,
  Clock,
  Zap,
  CheckCircle2,
  ShieldCheck,
  Code,
  ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import FundingModal from '@/src/components/FundingModal';
import WithdrawModal from '@/src/components/WithdrawModal';
import TransactionsModal from '@/src/components/TransactionsModal';
import SettingsModal from '@/src/components/SettingsModal';
import NotificationCenter from '@/src/components/NotificationCenter';
import SubmitWorkModal from '@/src/components/SubmitWorkModal';

interface DashboardProps {
  onNavigate: () => void;
}

interface Task {
  id: string;
  title: string;
  reward: number;
  description: string;
  status: string;
  publisher: string;
}

export default function Dashboard({ onNavigate }: DashboardProps) {
  const [activeTab, setActiveTab] = useState('tasks');
  const [isFundingModalOpen, setIsFundingModalOpen] = useState(false);
  const [isWithdrawModalOpen, setIsWithdrawModalOpen] = useState(false);
  const [isTxModalOpen, setIsTxModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState(false);
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);
  const [selectedTaskTitle, setSelectedTaskTitle] = useState('');
  
  const [tasks, setTasks] = useState<Task[]>([]);
  const [appliedTasks, setAppliedTasks] = useState<string[]>([]);
  const [submittedTasks, setSubmittedTasks] = useState<string[]>([]);

  useEffect(() => {
    fetch('/api/tasks', { headers: { 'Authorization': `Bearer ${localStorage.getItem('auth_token')}` } }).then(res => res.json()).then(data => {
      if (Array.isArray(data)) setTasks(data);
    });
    fetch('/api/applications', { headers: { 'Authorization': `Bearer ${localStorage.getItem('auth_token')}` } }).then(res => res.json()).then(data => {
      // Very basic mock login: assume current intern is dibyajyotichakrabarty391@gmail.com
      const userEmail = "dibyajyotichakrabarty391@gmail.com"; 
      const myApps = data.filter((a: any) => a.intern === userEmail);
      setAppliedTasks(myApps.map((a: any) => a.taskId));
      setSubmittedTasks(myApps.filter((a: any) => ['evaluating_ai', 'pending_human', 'approved', 'rejected'].includes(a.status)).map((a: any) => a.taskId));
    });
  }, []);

  const handleApply = async (taskId: string) => {
    try {
      const res = await fetch('/api/applications/apply', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('auth_token')}` },
        body: JSON.stringify({ taskId, intern: "dibyajyotichakrabarty391@gmail.com" })
      });
      if (!res.ok) throw new Error("Failed to apply");
      setAppliedTasks(prev => [...prev, taskId]);
      toast.success('Application submitted successfully!');
    } catch(e) {
      toast.error('Failed to apply');
    }
  };

  const handleOpenSubmitModal = (task: Task) => {
    setSelectedTaskId(task.id);
    setSelectedTaskTitle(task.title);
    setIsSubmitModalOpen(true);
  };

  const handleSubmitWork = async (proofUrl: string, notes: string) => {
    if (!selectedTaskId) return;
    
    toast('Evaluating by AI...', {
      description: 'Your submission is undergoing technical review.',
      duration: 3000,
    });
    setSubmittedTasks(prev => [...prev, selectedTaskId]);
    
    try {
      await fetch('/api/applications/submit', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('auth_token')}` },
        body: JSON.stringify({ 
          taskId: selectedTaskId, 
          intern: "dibyajyotichakrabarty391@gmail.com",
          proofUrl,
          notes
        })
      });
      setTimeout(() => {
        toast.success('Passed AI Evaluation', {
          description: 'Submission verified. Escalated to Human Evaluator for final review.',
          duration: 5000,
        });
      }, 3000);
    } catch(e) {
      toast.error("Failed to submit work");
    }
  };

  const handleWithdraw = () => {
    setIsWithdrawModalOpen(true);
  };

  const handleTxHistory = () => {
    setIsTxModalOpen(true);
  };

  const handleShareProfile = () => {
    toast.success('Profile link copied to clipboard!');
  };

  const handleSettings = () => {
    setIsSettingsModalOpen(true);
  };

  return (
    <div className="flex h-screen bg-background overflow-hidden text-foreground">
      <FundingModal isOpen={isFundingModalOpen} onClose={() => setIsFundingModalOpen(false)} />
      <WithdrawModal isOpen={isWithdrawModalOpen} onClose={() => setIsWithdrawModalOpen(false)} />
      <TransactionsModal isOpen={isTxModalOpen} onClose={() => setIsTxModalOpen(false)} />
      <SettingsModal isOpen={isSettingsModalOpen} onClose={() => setIsSettingsModalOpen(false)} onLogout={onNavigate} />
      <SubmitWorkModal 
        isOpen={isSubmitModalOpen} 
        onClose={() => setIsSubmitModalOpen(false)} 
        onSubmit={handleSubmitWork}
        taskTitle={selectedTaskTitle}
      />
      {/* Sidebar - Linear Inspired */}
      <aside className="w-64 border-r border-white/5 bg-[#081225]/80 backdrop-blur-xl flex flex-col pt-6 hidden md:flex z-20">
        <div className="px-6 mb-8 cursor-pointer" onClick={onNavigate}>
           <div className="flex items-center space-x-3">
             <img src="/logo.png" alt="InternLoop" className="h-[32px] w-auto object-contain rounded-md" />
           </div>
        </div>
        
        <div className="px-4 space-y-1">
          <p className="px-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 mt-4">Menu</p>
          {[
            { id: 'dashboard', icon: LayoutDashboard, label: 'Dashboard' },
            { id: 'tasks', icon: Briefcase, label: 'Task Marketplace' },
            { id: 'leaderboard', icon: Trophy, label: 'Leaderboard' },
            { id: 'wallet', icon: Wallet, label: 'Wallet & Earnings' },
            { id: 'profile', icon: UserCircle, label: 'My Portfolio' },
          ].map((item) => (
            <div 
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center space-x-3 px-3 py-2 rounded-lg cursor-pointer transition-all duration-200 group ${
                activeTab === item.id 
                  ? 'bg-intern-blue/10 text-intern-blue font-medium' 
                  : 'text-muted-foreground hover:bg-white/5 hover:text-white'
              }`}
            >
              <item.icon className={`w-4 h-4 ${activeTab === item.id ? 'text-intern-blue' : 'group-hover:text-white'}`} />
              <span>{item.label}</span>
            </div>
          ))}
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative h-full overflow-hidden">
        {/* Subtle Background Glows */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-intern-blue/5 rounded-full blur-[120px] pointer-events-none" />
        
        {/* Top Navbar */}
        <header className="h-16 border-b border-white/5 glass-panel z-10 flex items-center justify-between px-6 sticky top-0">
          <div className="flex items-center bg-black/20 rounded-full px-4 py-1.5 w-64 border border-white/5 focus-within:border-white/20 transition-colors">
            <Search className="w-4 h-4 text-muted-foreground mr-2" />
            <input 
              type="text" 
              placeholder="Search tasks..." 
              className="bg-transparent border-none outline-none text-sm text-white placeholder:text-muted-foreground w-full"
            />
          </div>
          
          <div className="flex items-center space-x-4">
            <NotificationCenter />
            <div className="h-8 w-8 rounded-full bg-gradient-to-tr from-intern-blue to-purple-500 p-[2px] cursor-pointer">
               <div className="w-full h-full rounded-full bg-[#0B1426] flex items-center justify-center">
                 <span className="text-xs font-bold text-white">P</span>
               </div>
            </div>
          </div>
        </header>

        {/* Scrollable Content Area */}
        <div className="flex-1 overflow-y-auto p-6 md:p-8 z-0 relative">
          
          <div className="max-w-5xl mx-auto space-y-8">
            
            {/* Page Header */}
            <div className="flex items-end justify-between">
              <div>
                <h2 className="text-3xl font-bold text-white mb-1 capitalize">
                  {activeTab === 'tasks' ? 'Task Marketplace' : activeTab === 'profile' ? 'My Portfolio' : activeTab}
                </h2>
                <p className="text-muted-foreground">Find work, build your reputation, and get hired.</p>
              </div>
              <div className="flex space-x-2">
                <Badge variant="outline" className="px-3 py-1 bg-intern-blue/10 text-intern-blue border-intern-blue/20 text-sm font-medium">WorkScore: 945</Badge>
              </div>
            </div>

            {/* Main Tab Content Display */}
            {activeTab === 'dashboard' && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                {[
                  { label: 'WorkScore', value: '945', icon: Trophy, trend: '+12 this week', color: 'text-intern-blue', glow: true },
                  { label: 'Tasks Completed', value: '24', icon: CheckCircle2, trend: '98% approval', color: 'text-intern-success' },
                  { label: 'Total Earnings', value: '₹4,250', icon: Wallet, trend: '+₹850 this month', color: 'text-yellow-500' },
                ].map((stat, i) => (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                    key={stat.label} 
                    className="glass-panel p-6 rounded-2xl hover:bg-white/[0.04] transition-colors group cursor-default"
                  >
                    <div className="flex justify-between items-start mb-4">
                      <p className="text-sm font-medium text-muted-foreground">{stat.label}</p>
                      <div className="p-2 bg-white/5 rounded-lg group-hover:bg-white/10 transition-colors">
                        <stat.icon className={`w-5 h-5 ${stat.color}`} />
                      </div>
                    </div>
                    <h3 className={`text-3xl font-bold text-white mb-1 ${stat.glow ? 'workscore-glow text-intern-sky' : ''}`}>{stat.value}</h3>
                    <p className="text-xs text-muted-foreground">{stat.trend}</p>
                  </motion.div>
                ))}
              </div>
            )}

            {/* Profile Tab */}
            {activeTab === 'profile' && (
               <div className="space-y-6">
                 {/* Profile Header */}
                 <div className="glass-panel p-8 rounded-2xl flex flex-col md:flex-row items-center md:items-start gap-8 relative overflow-hidden">
                    <div className="absolute right-0 top-0 w-64 h-64 bg-intern-blue/5 blur-3xl rounded-full" />
                    
                    <div className="w-32 h-32 rounded-full bg-gradient-to-tr from-intern-blue to-purple-500 p-1 flex-shrink-0 relative">
                       <div className="w-full h-full rounded-full bg-[#0B1426] flex items-center justify-center border-4 border-[#081225]">
                         <span className="text-5xl font-bold text-white">P</span>
                       </div>
                       <div className="absolute -bottom-2 -right-2 bg-intern-success p-2 rounded-full border-4 border-[#081225]">
                         <ShieldCheck className="w-5 h-5 text-white" />
                       </div>
                    </div>

                    <div className="flex-1 text-center md:text-left z-10">
                      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                        <div>
                          <h2 className="text-3xl font-bold text-white mb-1 flex items-center justify-center md:justify-start gap-3">
                            Pritam Kumar <Badge className="bg-intern-sky/10 text-intern-sky border-intern-sky/20">Elite Rank</Badge>
                          </h2>
                          <p className="text-muted-foreground mb-4">internloop.com/u/pritam</p>
                        </div>
                        <div className="flex gap-3">
                           <Button className="bg-white text-intern-navy hover:bg-white/90" onClick={handleShareProfile}>Share Profile</Button>
                           <Button variant="outline" className="border-white/10 glass-panel" onClick={handleSettings}>Settings</Button>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                         <div className="glass-panel rounded-xl p-4 border border-white/5">
                            <p className="text-xs text-muted-foreground mb-1 uppercase tracking-wider">WorkScore</p>
                            <p className="text-2xl font-bold text-intern-sky workscore-glow">945</p>
                         </div>
                         <div className="glass-panel rounded-xl p-4 border border-white/5 flex flex-col">
                            <p className="text-xs text-muted-foreground mb-1 uppercase tracking-wider">Honor Score</p>
                            <p className="text-2xl font-bold text-white mb-2">99<span className="text-sm text-muted-foreground">/100</span></p>
                            <div className="indicator-line mt-auto">
                              <div className="indicator-fill" style={{ width: '99%' }} />
                            </div>
                         </div>
                         <div className="glass-panel rounded-xl p-4 border border-white/5 flex flex-col">
                            <p className="text-xs text-muted-foreground mb-1 uppercase tracking-wider">Reliability</p>
                            <p className="text-2xl font-bold text-intern-success mb-2">98%</p>
                            <div className="indicator-line mt-auto">
                              <div className="indicator-fill bg-intern-success" style={{ width: '98%' }} />
                            </div>
                         </div>
                         <div className="glass-panel rounded-xl p-4 border border-white/5">
                            <p className="text-xs text-muted-foreground mb-1 uppercase tracking-wider">Total Earned</p>
                            <p className="text-2xl font-bold text-white">₹4.2k</p>
                         </div>
                      </div>
                    </div>
                 </div>

                 {/* Verified Skills */}
                 <div className="glass-panel p-8 rounded-2xl">
                    <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                       <CheckCircle2 className="w-5 h-5 text-intern-sky" /> Verified Skills
                    </h3>
                    <div className="flex flex-wrap gap-4">
                       {['React', 'Next.js', 'Typescript', 'PostgreSQL', 'UI/UX Design', 'Tailwind CSS'].map(skill => (
                          <div key={skill} className="flex items-center gap-3 px-4 py-3 rounded-xl bg-white/5 border border-white/10 hover:border-intern-blue/30 transition-colors cursor-default">
                             <div className="w-2 h-2 rounded-full bg-intern-blue" />
                             <span className="font-medium text-white">{skill}</span>
                             <Badge className="bg-intern-blue/10 text-intern-blue ml-2 border-0">Level 4</Badge>
                          </div>
                       ))}
                    </div>
                 </div>

                 {/* Work History */}
                 <div className="glass-panel p-8 rounded-2xl">
                    <h3 className="text-lg font-bold text-white mb-6">Verified Work History</h3>
                    <div className="space-y-4">
                       {[
                         { title: 'Razorpay Integration Modules', date: 'Oct 2023', score: '98/100', reward: '₹800', company: 'FinTech Startup' },
                         { title: 'Interactive Analytics Dashboard', date: 'Sep 2023', score: '95/100', reward: '₹1200', company: 'DataFlow Inc.' },
                         { title: 'Customer Support AI Agent', date: 'Aug 2023', score: '96/100', reward: '₹750', company: 'Acme Corp' },
                       ].map((work, idx) => (
                          <div key={idx} className="flex flex-col md:flex-row md:items-center justify-between p-4 rounded-xl border border-white/5 hover:bg-white/5 transition-colors gap-4">
                             <div>
                                <h4 className="font-bold text-white mb-1">{work.title}</h4>
                                <p className="text-sm text-muted-foreground">Completed for {work.company} • {work.date}</p>
                             </div>
                             <div className="flex items-center gap-6">
                               <div className="text-right">
                                 <p className="text-xs text-muted-foreground uppercase tracking-widest mb-1">Evaluator Score</p>
                                 <p className="font-medium text-intern-success">{work.score}</p>
                               </div>
                               <div className="text-right">
                                 <p className="text-xs text-muted-foreground uppercase tracking-widest mb-1">Earned</p>
                                 <p className="font-medium text-white">{work.reward}</p>
                               </div>
                               <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-white">
                                 <ArrowRight className="w-5 h-5" />
                               </Button>
                             </div>
                          </div>
                       ))}
                    </div>
                 </div>
               </div>
            )}

            {/* Tasks Section / Active specifically when tasks OR dashboard is showing tasks logic */}
            {(activeTab === 'tasks' || activeTab === 'dashboard') && (
              <div className="mt-8">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-white">Recommended Tasks</h3>
                  <Button variant="ghost" className="text-intern-sky hover:text-intern-sky/80">View all</Button>
                </div>

                <div className="grid grid-cols-1 gap-4">
                  <AnimatePresence>
                    {tasks.map((task, i) => (
                      <motion.div
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.2 + (i * 0.1) }}
                        key={task.id}
                        className="glass-card p-6 rounded-xl group hover:-translate-y-1 transition-all duration-300 cursor-pointer border border-white/5 hover:border-intern-blue/30"
                      >
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                          <div className="space-y-1 md:w-1/2">
                            <div className="flex items-center space-x-2 text-xs text-muted-foreground mb-2">
                              <span className="flex items-center"><ShieldCheck className="w-3 h-3 mr-1 text-intern-success" /> Verified Owner</span>
                              <span>•</span>
                              <span>{task.publisher}</span>
                            </div>
                            <h4 className="text-xl font-bold text-white group-hover:text-intern-sky transition-colors">{task.title}</h4>
                            <div className="flex flex-wrap gap-2 pt-2">
                              <Badge variant="secondary" className="bg-white/5 hover:bg-white/10 text-xs font-normal text-muted-foreground">
                                {task.description.substring(0, 40)}...
                              </Badge>
                            </div>
                          </div>

                          <div className="flex items-center md:justify-end gap-6 md:w-1/2">
                            <div className="text-right">
                              <p className="text-xs text-muted-foreground mb-1">Reward</p>
                              <p className="text-xl font-bold text-intern-success">₹{task.reward}</p>
                            </div>
                            <Button 
                              className={`${
                                submittedTasks.includes(task.id) 
                                  ? 'bg-purple-500/20 text-purple-400 hover:bg-purple-500/20 border border-purple-500/30'
                                  : appliedTasks.includes(task.id) 
                                    ? 'bg-intern-blue text-white hover:bg-intern-blue/90' 
                                    : 'bg-white text-intern-navy hover:bg-white/90'
                                } font-medium ${appliedTasks.includes(task.id) ? 'w-32' : 'w-24'}`}
                              onClick={(e) => {
                                e.stopPropagation();
                                if(!appliedTasks.includes(task.id)) {
                                  handleApply(task.id);
                                } else if (!submittedTasks.includes(task.id)) {
                                  handleOpenSubmitModal(task);
                                }
                              }}
                              disabled={submittedTasks.includes(task.id)}
                            >
                              {submittedTasks.includes(task.id) 
                                ? 'AI Correlating...' 
                                : appliedTasks.includes(task.id) 
                                  ? 'Submit Work' 
                                  : 'Apply'
                              }
                            </Button>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              </div>
            )}

            {/* Leaderboard Tab */}
            {activeTab === 'leaderboard' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Top 3 Podiums */}
                  {[
                    { rank: 2, name: 'Sara Chen', score: '976', earned: '₹16,100', color: 'from-slate-400 to-slate-500' },
                    { rank: 1, name: 'Arjun Mehta', score: '982', earned: '₹18,420', color: 'from-amber-400 to-orange-500' },
                    { rank: 3, name: 'Leo K.', score: '965', earned: '₹15,500', color: 'from-orange-400 to-red-500' },
                  ].map((user) => (
                    <div key={user.rank} className={`glass-panel p-6 rounded-2xl flex flex-col items-center justify-center relative ${user.rank === 1 ? 'md:-translate-y-4 border-intern-blue/30 shadow-[0_0_30px_rgba(37,99,235,0.2)]' : ''}`}>
                      {user.rank === 1 && <Trophy className="absolute -top-4 w-8 h-8 text-yellow-500 mx-auto" />}
                      <div className={`w-20 h-20 rounded-full bg-gradient-to-br ${user.color} p-1 mb-4`}>
                        <div className="w-full h-full rounded-full bg-[#0B1426] flex items-center justify-center font-bold text-xl text-white">
                          {user.name.charAt(0)}
                        </div>
                      </div>
                      <Badge className="bg-white/10 text-white border-0 mb-3">Rank #{user.rank}</Badge>
                      <h3 className="text-lg font-bold text-white text-center mb-1">{user.name}</h3>
                      <p className="text-sm text-intern-sky font-semibold mb-3 workscore-glow">{user.score} WS</p>
                      <p className="text-xs text-muted-foreground">{user.earned} Earned</p>
                    </div>
                  ))}
                </div>

                <div className="glass-panel rounded-2xl overflow-hidden mt-8">
                  <div className="p-6 border-b border-white/5 flex items-center justify-between">
                    <h3 className="font-bold text-white">Global Top 100</h3>
                    <Badge variant="outline" className="border-white/10 text-muted-foreground">Season 4</Badge>
                  </div>
                  <div className="divide-y divide-white/5">
                    {[
                      { rank: 4, name: 'Pritam Kumar', score: 945, tags: ['React', 'Next.js'] },
                      { rank: 5, name: 'Elena R.', score: 920, tags: ['UI/UX', 'Figma'] },
                      { rank: 6, name: 'David M.', score: 915, tags: ['Python', 'AI'] },
                      { rank: 7, name: 'Sarah J.', score: 902, tags: ['Rust', 'Backend'] },
                      { rank: 8, name: 'Michael T.', score: 890, tags: ['PostgreSQL'] },
                    ].map((user) => (
                      <div key={user.rank} className={`p-4 flex items-center justify-between hover:bg-white/5 transition-colors ${user.rank === 4 ? 'bg-intern-blue/5 border-l-2 border-intern-blue' : ''}`}>
                        <div className="flex items-center gap-4">
                          <span className="text-sm font-bold w-6 text-center text-muted-foreground">{user.rank}</span>
                          <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center font-bold text-white text-sm border border-white/10">
                            {user.name.charAt(0)}
                          </div>
                          <div>
                            <p className="font-medium text-white">{user.name} {user.rank === 4 && <span className="text-[10px] text-intern-blue ml-2 uppercase tracking-wide font-bold">You</span>}</p>
                            <div className="flex gap-2 mt-1">
                              {user.tags.map(t => <span key={t} className="text-[10px] text-muted-foreground">{t}</span>)}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-intern-sky workscore-glow">{user.score}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Wallet Tab */}
            {activeTab === 'wallet' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="glass-panel p-8 rounded-2xl relative overflow-hidden">
                    <div className="absolute right-0 bottom-0 w-48 h-48 bg-intern-blue/10 blur-3xl rounded-full" />
                    <p className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-2">Available Balance</p>
                    <h2 className="text-5xl font-bold text-white mb-6">₹3,450.00</h2>
                    <div className="flex flex-wrap gap-4">
                      <Button onClick={() => setIsFundingModalOpen(true)} className="bg-intern-blue text-white hover:bg-intern-blue/90 w-full sm:w-auto">Fund Wallet</Button>
                      <Button onClick={handleWithdraw} className="bg-white text-intern-navy hover:bg-white/90 w-full sm:w-auto">Withdraw Funds</Button>
                      <Button onClick={handleTxHistory} variant="outline" className="border-white/10 text-white w-full sm:w-auto">Transaction History</Button>
                    </div>
                  </div>
                  
                  <div className="glass-panel p-8 rounded-2xl flex flex-col justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-2">In Escrow (Pending Review)</p>
                      <h2 className="text-3xl font-bold text-white mb-2">₹800.00</h2>
                      <p className="text-sm text-muted-foreground">From 2 active tasks</p>
                    </div>
                    <div className="mt-6 flex items-center justify-between p-4 bg-white/5 border border-white/5 rounded-xl">
                      <div className="flex items-center gap-3">
                        <ShieldCheck className="w-5 h-5 text-intern-success" />
                        <div>
                          <p className="text-sm font-medium text-white">Escrow Protection Active</p>
                          <p className="text-[10px] text-muted-foreground">Funds secured by InternLoop</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="glass-panel p-8 rounded-2xl">
                  <h3 className="text-lg font-bold text-white mb-6">Recent Activity</h3>
                  <div className="space-y-4">
                    {[
                      { type: 'Payment Released', task: 'Razorpay Integration Modules', amount: '+₹800', date: 'Oct 15, 2023', status: 'Completed', color: 'text-intern-success' },
                      { type: 'Escrow Locked', task: 'Interactive Analytics Dashboard', amount: '₹1,200', date: 'Oct 12, 2023', status: 'Pending Review', color: 'text-yellow-500' },
                      { type: 'Withdrawal', task: 'Bank Transfer (**** 4211)', amount: '-₹1,500', date: 'Oct 10, 2023', status: 'Settled', color: 'text-white' },
                    ].map((tx, idx) => (
                       <div key={idx} className="flex flex-col md:flex-row md:items-center justify-between p-4 rounded-xl border border-white/5 hover:bg-white/5 transition-colors gap-4">
                         <div className="flex items-center gap-4">
                           <div className={`w-10 h-10 rounded-full flex items-center justify-center bg-white/5 border border-white/10`}>
                             {tx.type === 'Withdrawal' ? <Wallet className="w-4 h-4 text-white" /> : <CheckCircle2 className={`w-4 h-4 ${tx.color}`} />}
                           </div>
                           <div>
                              <h4 className="font-bold text-white mb-1 tracking-tight">{tx.type}</h4>
                              <p className="text-xs text-muted-foreground">{tx.task}</p>
                           </div>
                         </div>
                         <div className="flex items-center md:items-end flex-col md:flex-col justify-between gap-1">
                            <span className={`font-bold ${tx.color}`}>{tx.amount}</span>
                            <span className="text-xs text-muted-foreground">{tx.date} • {tx.status}</span>
                         </div>
                       </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

          </div>
        </div>
      </main>
    </div>
  );
}
