import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface PrivacyPolicyProps {
  onBack: () => void;
}

export default function PrivacyPolicy({ onBack }: PrivacyPolicyProps) {
  return (
    <div className="flex min-h-screen flex-col bg-background relative overflow-hidden text-white px-6 py-12">
      <div className="max-w-4xl mx-auto w-full relative z-10 glass-panel p-8 md:p-12 rounded-2xl">
        <Button variant="ghost" onClick={onBack} className="mb-8 hover:bg-white/5 text-muted-foreground hover:text-white -ml-4">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <h1 className="text-4xl font-bold mb-4">Privacy Policy for Internloop</h1>
        <p className="text-muted-foreground mb-8">Last Updated: 18-06-2026</p>

        <div className="space-y-6 text-muted-foreground leading-relaxed">
          <p>Internloop ("we", "our", "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, and protect your information when you use our website.</p>
          
          <h2 className="text-2xl font-bold text-white mt-8 mb-4">Information We Collect</h2>
          <p>We collect name, email, phone number, and payment details only when you make a purchase or contact us.</p>
          
          <h2 className="text-2xl font-bold text-white mt-8 mb-4">How We Use Information</h2>
          <p>We use your data to process payments, provide customer support, and improve our services. We do not sell your data to third parties.</p>
          
          <h2 className="text-2xl font-bold text-white mt-8 mb-4">Payment Security</h2>
          <p>All payments are processed securely via Razorpay. We do not store your card/UPI details on our servers.</p>
          
          <h2 className="text-2xl font-bold text-white mt-8 mb-4">Contact Us</h2>
          <p>For any privacy questions: dibyajyotichakrabarty391@gmail.com</p>
        </div>
      </div>
    </div>
  );
}
