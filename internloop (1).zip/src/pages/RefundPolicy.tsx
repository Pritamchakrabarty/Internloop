import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface RefundPolicyProps {
  onBack: () => void;
}

export default function RefundPolicy({ onBack }: RefundPolicyProps) {
  return (
    <div className="flex min-h-screen flex-col bg-background relative overflow-hidden text-white px-6 py-12">
      <div className="max-w-4xl mx-auto w-full relative z-10 glass-panel p-8 md:p-12 rounded-2xl">
        <Button variant="ghost" onClick={onBack} className="mb-8 hover:bg-white/5 text-muted-foreground hover:text-white -ml-4">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <h1 className="text-4xl font-bold mb-6">Refund & Cancellation Policy for Internloop</h1>

        <div className="space-y-6 text-muted-foreground leading-relaxed">
          <p>Since Internloop provides digital services/products:</p>
          
          <h2 className="text-2xl font-bold text-white mt-8 mb-4">No Refund Policy</h2>
          <p>Due to the digital nature of our services, all sales are final. Once payment is successful, no refund will be provided.</p>
          
          <h2 className="text-2xl font-bold text-white mt-8 mb-4">Failed Transaction</h2>
          <p>If money is debited but payment fails, the amount will be auto-refunded by Razorpay within 5-7 business days.</p>
          
          <h2 className="text-2xl font-bold text-white mt-8 mb-4">Cancellation</h2>
          <p>Orders cannot be cancelled once payment is completed.</p>
          
          <div className="mt-12 p-6 bg-white/5 rounded-xl border border-white/10">
            <p className="font-medium text-white mb-2">For support:</p>
            <p>Email: dibyajyotichakrabarty391@gmail.com</p>
            <p>Phone: +91 9827746174</p>
          </div>
        </div>
      </div>
    </div>
  );
}
