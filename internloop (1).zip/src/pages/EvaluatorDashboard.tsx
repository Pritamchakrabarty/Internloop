import React, { useState, useEffect } from 'react';
import { 
  ClipboardList, 
  CheckCircle2, 
  XCircle, 
  Clock,
  Bot,
  User,
  Settings,
  Eye,
  MessageSquare
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import SettingsModal from '@/src/components/SettingsModal';
import NotificationCenter from '@/src/components/NotificationCenter';

interface EvaluatorDashboardProps {
  onNavigate: () => void;
}

interface Application {
  id: string;
  taskId: string;
  taskTitle: string;
  intern: string;
  status: string;
  aiScore?: number;
  aiFeedback?: string;
  proofUrl?: string;
  notes?: string;
  evaluatorFeedback?: string;
}

export default function EvaluatorDashboard({ onNavigate }: EvaluatorDashboardProps) {
  const [activeTab, setActiveTab] = useState('queue');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [reviews, setReviews] = useState<Application[]>([]);

  const fetchApplications = async () => {
    try {
      const res = await fetch('/api/applications', { headers: { 'Authorization': `Bearer ${localStorage.getItem('auth_token')}` } });
      const data = await res.json();
      setReviews(data);
    } catch(e) {}
  };

  useEffect(() => {
    fetchApplications();
    const interval = setInterval(fetchApplications, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleEvaluate = async (id: string, action: 'approve'|'reject') => {
    try {
      const res = await fetch('/api/applications/evaluate', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('auth_token')}` },
        body: JSON.stringify({ applicationId: id, evaluator: 'admin@internloop.com', action, feedback: 'Human verified' })
      });
      if(!res.ok) throw new Error();
      if(action === 'approve') {
        toast.success("Submission Approved", { description: "Verified score sent to Publisher plugin trigger payment." });
      } else {
        toast.error("Submission Rejected");
      }
      fetchApplications();
    } catch(e) {
      toast.error("Failed to submit evaluation");
    }
  };

  const handleReject = (id: number) => {
    toast.error("Submission Rejected", { description: "Feedback sent to intern for revision." });
    setReviews(reviews.map(r => r.id === id ? { ...r, status: 'rejected' } : r));
  };

  return (
    <div className="flex h-screen bg-[#020617] overflow-hidden text-foreground">
      <SettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} onLogout={onNavigate} />
      {/* Sidebar */}
      <aside className="w-64 border-r border-white/5 bg-[#081225]/80 backdrop-blur-xl flex flex-col pt-6 hidden md:flex z-20">
        <div className="px-6 mb-8 cursor-pointer" onClick={onNavigate}>
           <div className="flex items-center space-x-3">
             <img src="/logo.png" alt="InternLoop" className="h-[32px] w-auto object-contain rounded-md" />
             <Badge className="bg-purple-500/20 text-purple-400 hover:bg-purple-500/20 border-0">Evaluator</Badge>
           </div>
        </div>
        
        <nav className="flex-1 px-4 space-y-2">
          {[
            { id: 'queue', icon: ClipboardList, label: 'Review Queue' },
            { id: 'history', icon: CheckCircle2, label: 'Past Evaluations' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                activeTab === item.id 
                  ? 'bg-white/10 text-white' 
                  : 'text-muted-foreground hover:text-white hover:bg-white/5'
              }`}
            >
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-white/5">
          <button 
            onClick={() => setIsSettingsOpen(true)}
            className="w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium text-muted-foreground hover:text-white hover:bg-white/5 transition-colors"
          >
            <Settings className="w-5 h-5" />
            <span>Settings</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative z-20 overflow-y-auto">
        <header className="h-16 border-b border-white/5 flex items-center justify-between px-8 bg-black/20 sticky top-0 backdrop-blur-sm z-30">
          <h1 className="text-xl font-bold text-white tracking-tight">Evaluator Workspace</h1>
          <NotificationCenter />
        </header>

        <div className="p-8 max-w-6xl mx-auto w-full">
          {activeTab === 'queue' && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              
              <div className="glass-panel p-6 rounded-2xl border border-white/5 flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-bold text-white mb-1">Human + AI Hybrid Pipeline</h2>
                  <p className="text-sm text-muted-foreground">Submissions are pre-screened by our AI Engine. You perform the final authoritative review.</p>
                </div>
                <Badge variant="outline" className="bg-purple-500/10 text-purple-400 border-purple-500/30 flex items-center gap-2 px-3 py-1.5">
                  <Bot className="w-4 h-4" /> AI Assisted Mode Active
                </Badge>
              </div>

              <div className="space-y-4">
                <h3 className="text-xl font-bold text-white mb-4">Pending Your Review</h3>
                {reviews.filter(r => r.status === 'pending_human' || r.status === 'evaluating_ai').map((review) => (
                  <div key={review.id} className="glass-panel p-6 rounded-2xl border border-white/5 flex flex-col md:flex-row gap-6">
                    <div className="flex-1 space-y-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="text-lg font-bold text-white">{review.taskTitle || "Task ID: "+review.taskId}</h4>
                          <p className="text-sm text-muted-foreground flex items-center gap-2 mt-1">
                            <User className="w-4 h-4" /> Intern: {review.intern.split('@')[0]} <span className="opacity-50">•</span> <Clock className="w-4 h-4" /> Just now
                          </p>
                        </div>
                      </div>

                      {(review.proofUrl || review.notes) && (
                        <div className="bg-secondary/30 rounded-xl p-4 border border-white/5 space-y-2">
                          {review.proofUrl && (
                            <p className="text-sm">
                              <span className="text-muted-foreground">Proof of Work:</span>{' '}
                              <a href={review.proofUrl} target="_blank" rel="noopener noreferrer" className="text-intern-blue hover:underline">
                                {review.proofUrl}
                              </a>
                            </p>
                          )}
                          {review.notes && (
                            <p className="text-sm">
                              <span className="text-muted-foreground">Notes:</span>{' '}
                              <span className="text-foreground">{review.notes}</span>
                            </p>
                          )}
                        </div>
                      )}

                      {review.status === 'evaluating_ai' ? (
                        <div className="bg-white/5 rounded-xl p-4 flex items-center gap-4 animate-pulse">
                          <Bot className="w-6 h-6 text-intern-sky" />
                          <div>
                            <p className="text-sm font-medium text-white mb-1">AI Evaluator is analyzing code...</p>
                            <p className="text-xs text-muted-foreground">Waiting for initial technical validation before human review unlocks.</p>
                          </div>
                        </div>
                      ) : (
                        <div className="bg-white/5 rounded-xl p-4 border border-intern-blue/20">
                          <div className="flex items-center gap-2 mb-2">
                            <Bot className="w-5 h-5 text-intern-sky" />
                            <span className="text-sm font-bold text-white">AI Technical Assessment</span>
                            <Badge className="ml-auto bg-intern-blue text-white border-0">Score: {review.aiScore || 0}/100</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground italic">"{review.aiFeedback || 'Evaluation feedback processing...'}"</p>
                        </div>
                      )}
                    </div>

                    <div className="md:w-64 flex flex-col justify-center space-y-3 border-t md:border-t-0 md:border-l border-white/5 pt-4 md:pt-0 md:pl-6">
                      {review.status === 'pending_human' ? (
                        <>
                          <Button variant="outline" className="w-full justify-start text-white border-white/10" onClick={() => review.proofUrl ? window.open(review.proofUrl, '_blank') : toast.info('Opening work preview...')}>
                            <Eye className="w-4 h-4 mr-2" /> View Work
                          </Button>
                          <Button className="w-full justify-start bg-intern-success/10 text-intern-success hover:bg-intern-success/20 border-0" onClick={() => handleEvaluate(review.id, 'approve')}>
                            <CheckCircle2 className="w-4 h-4 mr-2" /> Approve & Confirm
                          </Button>
                          <Button className="w-full justify-start bg-red-500/10 text-red-500 hover:bg-red-500/20 border-0" onClick={() => handleEvaluate(review.id, 'reject')}>
                            <XCircle className="w-4 h-4 mr-2" /> Reject & Request Changes
                          </Button>
                        </>
                      ) : (
                        <Button disabled variant="outline" className="w-full text-muted-foreground border-white/10 opacity-50">
                          Locked: Awaiting AI
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
                {reviews.filter(r => r.status === 'pending_human' || r.status === 'evaluating_ai').length === 0 && (
                   <div className="text-center p-8 text-muted-foreground">No applications pending review.</div>
                )}
            </div>
            </div>
          )}

          {activeTab === 'history' && (
            <div className="glass-panel p-8 rounded-2xl border border-white/5 flex flex-col items-center justify-center text-center min-h-[400px]">
              <CheckCircle2 className="w-16 h-16 text-intern-success/20 mb-4" />
              <h3 className="text-xl font-bold text-white mb-2">You're all caught up!</h3>
              <p className="text-muted-foreground max-w-md">You've completed all historical evaluations. Good job maintaining the platform quality.</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
