import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Code, Trophy, ShieldCheck, Stars, Zap, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface LandingProps {
  onLogin: () => void;
  onSignup: () => void;
  onStart: () => void;
  onGoToPublisher?: () => void;
  onGoToAdmin?: () => void;
  onGoToEvaluator?: () => void;
  onGoToManifesto?: () => void;
  onGoToHowItWorks?: () => void;
}

export default function Landing({ onLogin, onSignup, onStart, onGoToPublisher, onGoToAdmin, onGoToEvaluator, onGoToManifesto, onGoToHowItWorks }: LandingProps) {
  return (
    <div className="flex min-h-screen flex-col bg-background relative overflow-hidden">
      {/* Background Gradients */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] opacity-20 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-r from-intern-blue to-intern-sky blur-[100px] rounded-full" />
      </div>

      {/* Navbar */}
      <nav className="flex items-center justify-between px-8 py-6 z-10 glass-panel border-b-0 sticky top-0">
        <div className="flex items-center space-x-2 cursor-pointer">
          <img src="/logo.png" alt="InternLoop" className="h-[40px] w-auto object-contain rounded-md" />
        </div>
        <div className="hidden md:flex items-center space-x-8 text-sm font-medium text-muted-foreground">
          <span className="hover:text-white transition-colors cursor-pointer" onClick={onGoToManifesto}>Manifesto</span>
          <span className="hover:text-white transition-colors cursor-pointer" onClick={onGoToHowItWorks}>How it Works</span>
          <span className="hover:text-white transition-colors cursor-pointer" onClick={onGoToAdmin}>Admin</span>
          <span className="hover:text-white transition-colors cursor-pointer" onClick={onGoToEvaluator}>Evaluators</span>
        </div>
        <div className="flex items-center space-x-3">
          <span className="text-sm font-medium text-muted-foreground hover:text-white transition-colors cursor-pointer mr-2" onClick={onGoToPublisher}>
            For Publishers
          </span>
          <Button 
            variant="ghost" 
            className="text-muted-foreground hover:text-white hover:bg-white/5 font-medium"
            onClick={onLogin}
          >
            Log in
          </Button>
          <Button 
            className="bg-white text-intern-navy hover:bg-gray-100 font-medium px-5 rounded-full"
            onClick={onSignup}
          >
            Sign up
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="flex-1 flex flex-col items-center justify-center px-4 py-24 text-center z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="max-w-4xl mx-auto flex flex-col items-center"
        >
          <Badge variant="outline" className="mb-6 py-1.5 px-4 text-intern-sky border-intern-sky/30 bg-intern-sky/10 rounded-full">
            <Stars className="w-3.5 h-3.5 mr-2" />
            The Proof-of-Work Network
          </Badge>
          
          <h1 className="text-6xl md:text-8xl font-bold tracking-tight text-white mb-6 leading-tight">
            Work. Prove. <br />
            <span className="gradient-text bg-gradient-to-r from-intern-sky via-intern-blue to-purple-500">Get Hired.</span>
          </h1>
          
          <p className="text-xl text-muted-foreground mb-10 max-w-2xl leading-relaxed">
            Build reputation through real work instead of resumes. Complete tasks, earn verified skills, and let your WorkScore™ launch your career.
          </p>

          <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-4">
            <Button size="lg" className="bg-intern-blue text-white hover:bg-intern-blue/90 h-12 px-8 text-base rounded-full" onClick={onStart}>
              Start Building Reputation <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
            <Button size="lg" variant="outline" className="border-white/10 hover:bg-white/5 text-white h-12 px-8 text-base rounded-full backdrop-blur-md">
              Explore Tasks
            </Button>
          </div>
        </motion.div>

        {/* Hero Visual Match */}
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
          className="mt-24 w-full max-w-5xl glass-card rounded-2xl border border-white/10 p-2 overflow-hidden relative shadow-2xl shadow-intern-blue/20"
        >
           <div className="absolute inset-0 bg-gradient-to-b from-white/5 to-transparent pointer-events-none" />
           {/* Mock Interface Header */}
           <div className="flex items-center space-x-2 px-4 py-3 border-b border-white/5 bg-black/20">
             <div className="w-3 h-3 rounded-full bg-red-500/80" />
             <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
             <div className="w-3 h-3 rounded-full bg-green-500/80" />
           </div>
           {/* Mock Interface Content */}
           <div className="p-8 grid grid-cols-1 md:grid-cols-3 gap-6 bg-[#0B1426]">
             <div className="col-span-2 space-y-4">
               <div className="flex space-x-4 mb-8">
                 <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-intern-blue to-purple-500 p-[2px]">
                   <div className="w-full h-full rounded-full bg-[#0B1426] flex items-center justify-center">
                     <span className="text-xl font-bold">P</span>
                   </div>
                 </div>
                 <div>
                   <h3 className="text-2xl font-bold text-white flex items-center">Pritam Kumar <Badge className="ml-3 bg-intern-sky/20 text-intern-sky border-intern-sky/30">Top 1%</Badge></h3>
                   <p className="text-muted-foreground">Full-Stack Developer</p>
                 </div>
               </div>
               {/* WorkScore Mock */}
               <div className="glass-panel p-6 rounded-xl relative overflow-hidden">
                  <div className="absolute right-0 top-0 w-32 h-32 bg-intern-sky/10 blur-3xl rounded-full" />
                  <p className="text-sm font-medium text-muted-foreground mb-1 uppercase tracking-wider">Verified WorkScore</p>
                  <p className="text-5xl font-bold text-intern-sky tracking-tight workscore-glow">945<span className="text-lg text-intern-success ml-2">↑ 12</span></p>
                  
                  <div className="mt-6 flex space-x-2">
                    {Array.from({length: 12}).map((_, i) => (
                      <div key={i} className={`h-8 w-6 rounded-sm ${i > 8 ? 'bg-white/5' : 'bg-intern-blue/80'}`} />
                    ))}
                  </div>
               </div>
             </div>
             
             <div className="space-y-4">
               {/* Stats Mock */}
               <div className="glass-panel p-5 rounded-xl flex items-center justify-between">
                 <div>
                   <p className="text-sm text-muted-foreground">Honor Score</p>
                   <p className="text-xl font-bold text-white">99/100</p>
                 </div>
                 <ShieldCheck className="text-intern-success w-8 h-8 opacity-80" />
               </div>
               <div className="glass-panel p-5 rounded-xl flex items-center justify-between">
                 <div>
                   <p className="text-sm text-muted-foreground">Tasks Completed</p>
                   <p className="text-xl font-bold text-white">24</p>
                 </div>
                 <CheckCircle2 className="text-intern-sky w-8 h-8 opacity-80" />
               </div>
               <div className="glass-panel p-5 rounded-xl flex items-center justify-between">
                 <div>
                   <p className="text-sm text-muted-foreground">Total Earned</p>
                   <p className="text-xl font-bold text-white">₹4,250</p>
                 </div>
                 <Zap className="text-yellow-500 w-8 h-8 opacity-80" />
               </div>
             </div>
           </div>
        </motion.div>
      </main>

      {/* Social Proof Section */}
      <section className="py-24 border-t border-white/5 bg-black/20 z-10">
        <div className="max-w-6xl mx-auto px-6">
          <p className="text-center text-sm font-medium text-muted-foreground uppercase tracking-widest mb-12">Trusted by builders & recruiters worldwide</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { label: 'Tasks Completed', value: '14,000+' },
              { label: 'Rewards Distributed', value: '₹850k+' },
              { label: 'Verified Skills Earned', value: '32,450' },
              { label: 'Active Interns', value: '8,200+' },
            ].map((stat, i) => (
              <div key={i} className="flex flex-col items-center">
                <span className="text-4xl md:text-5xl font-bold text-white mb-2">{stat.value}</span>
                <span className="text-muted-foreground font-medium">{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section className="py-32 px-6 z-10">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">The new career path.</h2>
            <p className="text-lg text-muted-foreground">Resume → Interview → Hiring <span className="line-through opacity-50 mx-2">is dead.</span></p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              { icon: Zap, title: "Accept Task", desc: "Choose a task that matches your skills. Solo or competitive mode." },
              { icon: Code, title: "Complete Work", desc: "Build it. Ship it. Submit your GitHub repo and Loom walkthrough." },
              { icon: ShieldCheck, title: "Get Evaluated", desc: "Expert evaluators review your code within 12 hours." },
              { icon: Trophy, title: "Build Reputation", desc: "Earn the reward, verified skills, and boost your WorkScore." },
            ].map((step, i) => (
              <div key={i} className="glass-panel p-8 rounded-2xl relative group">
                <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center mb-6 group-hover:bg-intern-blue/20 transition-colors">
                  <step.icon className="w-6 h-6 text-intern-sky" />
                </div>
                <h3 className="text-xl font-bold text-white mb-3">{step.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{step.desc}</p>
                
                {/* Connector line for large screens */}
                {i !== 3 && (
                  <div className="hidden md:block absolute top-14 left-[calc(100%-24px)] w-[48px] h-[2px] bg-white/10" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
