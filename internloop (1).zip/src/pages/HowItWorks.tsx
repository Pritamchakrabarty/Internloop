import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import { 
  ArrowRight, CheckCircle2, ShieldCheck, Zap, Code2, 
  BrainCircuit, Users, Award, Briefcase, FileCode2,
  FolderLock, Rocket, Activity, Shield, Laptop, Swords
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export default function HowItWorks({ onBack, onStart }: { onBack: () => void, onStart: () => void }) {
  const containerRef = useRef<HTMLDivElement>(null);
  
  const steps = [
    {
      step: "01",
      title: "A Professional Needs Help",
      desc: "A professional, founder, freelancer, or employee has work that needs to be completed. Instead of letting deadlines pile up, they post a verified task on InternLoop.",
      icon: Briefcase,
      color: "from-blue-500 to-indigo-500",
      visual: (
        <div className="relative w-full h-48 bg-white/5 rounded-2xl border border-white/10 overflow-hidden flex items-center justify-center p-6">
          <div className="space-y-4 w-full">
            <div className="h-2 w-1/3 bg-white/20 rounded"></div>
            <div className="h-2 w-1/2 bg-white/10 rounded"></div>
            <div className="h-2 w-2/3 bg-white/10 rounded"></div>
            <div className="flex gap-2 pt-4">
              <div className="h-8 w-24 bg-red-500/20 rounded flex items-center justify-center text-xs text-red-500 font-bold border border-red-500/30">OVERDUE</div>
              <div className="h-8 w-24 bg-intern-blue/20 rounded flex items-center justify-center text-xs text-intern-sky font-bold border border-intern-blue/30 scale-105 animate-pulse">POST TASK <ArrowRight className="w-3 h-3 ml-1"/></div>
            </div>
          </div>
        </div>
      )
    },
    {
      step: "02",
      title: "Task Goes Live",
      desc: "Requirements, reward, deadline, and tech stack are defined. Every task is funded through escrow. Payment is secured before work begins.",
      icon: Activity,
      color: "from-intern-blue to-intern-sky",
      visual: (
        <div className="relative w-full h-48 bg-[#0a0f1d] rounded-2xl border border-intern-blue/30 overflow-hidden flex flex-col justify-center p-6 shadow-[0_0_30px_rgba(56,189,248,0.1)]">
          <div className="flex justify-between items-start mb-4">
            <div>
              <div className="text-white font-bold mb-1">Build Landing Page</div>
              <div className="flex gap-2">
                <Badge variant="outline" className="text-[10px] border-white/10 text-muted-foreground">React</Badge>
                <Badge variant="outline" className="text-[10px] border-white/10 text-muted-foreground">Tailwind</Badge>
              </div>
            </div>
            <div className="text-intern-success font-bold text-lg">₹5000</div>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground bg-white/5 p-2 rounded-lg border border-intern-success/20 w-fit">
            <FolderLock className="w-4 h-4 text-intern-success" /> Escrow Funded
          </div>
        </div>
      )
    },
    {
      step: "03",
      title: "Intern Accepts The Challenge",
      desc: "Interns browse verified opportunities and choose tasks that match their skills. No resumes. No networking. Only real work.",
      icon: Users,
      color: "from-purple-500 to-pink-500",
      visual: (
        <div className="relative w-full h-48 bg-white/5 rounded-2xl border border-white/10 overflow-hidden flex items-center justify-center">
            <div className="w-16 h-16 rounded-full bg-purple-500/20 border border-purple-500/30 flex items-center justify-center z-10 animate-bounce">
              <Laptop className="w-8 h-8 text-purple-400" />
            </div>
            <ArrowRight className="w-6 h-6 text-white/20 absolute right-8" />
            <ArrowRight className="w-6 h-6 text-white/20 absolute left-8 rotate-180" />
        </div>
      )
    },
    {
      step: "04",
      title: "Work Gets Built",
      desc: "The intern completes the work. AI tracks activity, progress, and milestones to ensure accountability.",
      icon: Code2,
      color: "from-green-500 to-emerald-500",
      visual: (
        <div className="relative w-full h-48 bg-black rounded-2xl border border-white/10 overflow-hidden p-4 font-mono text-xs text-green-500 flex flex-col justify-end">
           <div className="opacity-40">&gt; git commit -m "feat: setup layout"</div>
           <div className="opacity-60">&gt; npm run build</div>
           <div className="opacity-80 pb-2">✓ compiled successfully in 1.2s</div>
           <div className="w-full h-1 bg-white/10 rounded overflow-hidden">
             <motion.div className="h-full bg-green-500" initial={{ width: "0%" }} whileInView={{ width: "100%" }} transition={{ duration: 2 }} />
           </div>
        </div>
      )
    },
    {
      step: "05",
      title: "Submit Work",
      desc: "Every submission includes proof of work (GitHub repo, Loom video, submission report). This creates transparency and trust.",
      icon: FileCode2,
      color: "from-orange-500 to-red-500",
      visual: (
        <div className="relative w-full h-48 bg-white/5 rounded-2xl border border-white/10 overflow-hidden p-6 flex items-center justify-center gap-4">
           <div className="w-1/3 aspect-square bg-[#1e293b] rounded-xl border border-white/10 flex flex-col items-center justify-center text-muted-foreground hover:bg-white/10 transition-colors">
              <Code2 className="w-8 h-8 mb-2" />
              <div className="text-[10px]">Repo</div>
           </div>
           <div className="w-1/3 aspect-square bg-[#1e293b] rounded-xl border border-white/10 flex flex-col items-center justify-center text-intern-sky hover:bg-white/10 transition-colors shadow-[0_0_15px_rgba(56,189,248,0.2)] scale-110">
              <CheckCircle2 className="w-8 h-8 mb-2" />
              <div className="text-[10px] font-bold">Submit</div>
           </div>
           <div className="w-1/3 aspect-square bg-[#1e293b] rounded-xl border border-white/10 flex flex-col items-center justify-center text-muted-foreground hover:bg-white/10 transition-colors">
              <FileCode2 className="w-8 h-8 mb-2" />
              <div className="text-[10px]">Report</div>
           </div>
        </div>
      )
    },
    {
      step: "06",
      title: "AI Quality Review",
      desc: "Before a human review begins, AI evaluates code quality, documentation, project structure, and requirement coverage. This speeds up evaluation.",
      icon: BrainCircuit,
      color: "from-cyan-500 to-blue-500",
      visual: (
        <div className="relative w-full h-48 bg-gradient-to-br from-cyan-950 to-blue-950 rounded-2xl border border-cyan-500/30 overflow-hidden p-6 flex flex-col justify-center">
           <div className="flex items-center gap-3 mb-4">
             <BrainCircuit className="w-6 h-6 text-cyan-400" />
             <span className="text-cyan-400 font-bold text-sm tracking-widest uppercase">Analyzing...</span>
           </div>
           <div className="space-y-2">
             <div className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-intern-success"/> <span className="text-xs text-white/80">Code structure intact</span></div>
             <div className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-intern-success"/> <span className="text-xs text-white/80">Requirements met (4/4)</span></div>
             <div className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-intern-success"/> <span className="text-xs text-white/80">No vulnerabilities</span></div>
           </div>
        </div>
      )
    },
    {
      step: "07",
      title: "Independent Evaluation",
      desc: "Independent evaluators verify the quality of work. Pass, fail, or request changes. Every decision includes feedback.",
      icon: ShieldCheck,
      color: "from-yellow-500 to-amber-500",
      visual: (
        <div className="relative w-full h-48 bg-white/5 rounded-2xl border border-white/10 overflow-hidden p-6 flex flex-col items-center justify-center">
           <div className="w-full flex justify-between gap-2">
             <Button variant="outline" className="w-full bg-red-500/10 text-red-500 border-red-500/30 hover:bg-red-500/20">Reject</Button>
             <Button variant="outline" className="w-full bg-intern-success/10 text-intern-success border-intern-success/30 hover:bg-intern-success/20 shadow-[0_0_20px_rgba(34,197,94,0.2)]">Approve</Button>
           </div>
           <div className="w-full p-3 bg-white/5 rounded-lg border border-white/10 mt-4 text-xs text-muted-foreground italic text-center">
             "Great implementation, code is clean and responsive. Passing verification."
           </div>
        </div>
      )
    },
    {
      step: "08",
      title: "Reputation Is Created",
      desc: "Reward is released. Certificate generated. WorkScore gets updated. Portfolio updates. This becomes permanent proof of capability.",
      icon: Award,
      color: "from-intern-sky to-purple-500",
      visual: (
        <div className="relative w-full h-48 bg-[#0a0a14] rounded-2xl border border-purple-500/30 overflow-hidden flex items-center justify-center">
           <div className="absolute inset-0 bg-gradient-to-tr from-intern-blue/20 to-purple-500/20 rounded-[3rem] blur-xl mix-blend-screen animate-pulse duration-3000"></div>
           <div className="relative z-10 text-center">
              <div className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-b from-white to-neutral-500">+145</div>
              <div className="text-[10px] font-bold text-intern-sky tracking-widest mt-1 uppercase">WorkScore Earned</div>
           </div>
        </div>
      )
    }
  ];

  return (
    <div ref={containerRef} className="bg-[#020617] text-white min-h-screen selection:bg-intern-sky selection:text-black font-sans relative overflow-x-hidden">
      
      {/* Dynamic Background Mesh */}
      <div className="fixed inset-0 z-0 pointer-events-none opacity-40">
        <div className="absolute top-[-10%] left-[-10%] w-[40vw] h-[40vw] rounded-full bg-intern-blue/20 blur-[120px] mix-blend-screen animate-pulse duration-10000" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50vw] h-[50vw] rounded-full bg-purple-900/20 blur-[150px] mix-blend-screen animate-pulse duration-7000" />
      </div>

      <nav className="fixed top-0 left-0 right-0 z-50 px-6 py-6 flex justify-between items-center backdrop-blur-md bg-black/50 border-b border-white/5 transition-all">
        <button onClick={onBack} className="text-xl font-bold flex items-center gap-2 group">
          <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-black font-black rotate-3 group-hover:rotate-0 transition-transform">
            i
          </div>
          <span className="tracking-tight">InternLoop</span>
        </button>
        <div className="hidden md:flex gap-8 items-center text-sm font-medium">
          <div className="text-white">How it Works</div>
          <Button onClick={onStart} className="bg-white text-black hover:bg-neutral-200 hover:scale-105 transition-all rounded-full px-6">
            Start Building
          </Button>
        </div>
      </nav>

      <main className="relative z-10">
        {/* HERO SECTION */}
        <section className="min-h-screen flex flex-col justify-center items-center px-6 pt-32 text-center relative overflow-hidden">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="flex items-center justify-center mb-6"
          >
            <Badge variant="outline" className="border-intern-sky/50 bg-intern-blue/10 text-intern-sky py-1 px-4 text-sm font-medium flex items-center gap-2">
              <Zap className="w-4 h-4 fill-intern-sky" /> The Future of Work
            </Badge>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="max-w-5xl mx-auto z-10"
          >
            <h1 className="text-5xl md:text-7xl font-bold tracking-tight leading-[1.1] mb-8 text-white">
              Build Your Career Through <span className="bg-gradient-to-r from-intern-sky via-purple-400 to-intern-blue bg-clip-text text-transparent">Proof</span>, Not Promises.
            </h1>
            
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 1 }}
              className="text-xl md:text-2xl text-neutral-400 max-w-2xl mx-auto space-y-4 mb-12 font-medium"
            >
              <p>InternLoop transforms real work into verified reputation.</p>
              <div className="py-6 flex flex-wrap justify-center gap-4 text-lg text-white font-medium">
                 <span>Complete tasks. <span className="text-intern-sky px-2">•</span></span>
                 <span>Earn rewards. <span className="text-intern-sky px-2">•</span></span>
                 <span>Build WorkScore. <span className="text-intern-sky px-2">•</span></span>
                 <span>Get hired.</span>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8, duration: 0.8 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Button onClick={onStart} size="lg" className="h-14 px-8 text-lg rounded-full bg-white text-black hover:bg-neutral-200">
                Start Building <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              <Button onClick={() => {
                document.getElementById('timeline')?.scrollIntoView({ behavior: 'smooth' });
              }} size="lg" variant="outline" className="h-14 px-8 text-lg rounded-full bg-white/5 text-white border-white/20 hover:bg-white/10">
                Explore Workflow
              </Button>
            </motion.div>
          </motion.div>
        </section>

        {/* WORKFLOW TIMELINE */}
        <section id="timeline" className="py-32 px-6 bg-black relative">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-24">
               <h2 className="text-sm font-bold text-intern-sky tracking-widest uppercase mb-4">The Ecosystem</h2>
               <h3 className="text-4xl md:text-5xl font-bold text-white">How Information Flows</h3>
            </div>

            <div className="relative">
               {/* Center Line */}
               <div className="absolute left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-white/20 to-transparent hidden md:block"></div>

               <div className="space-y-32">
                 {steps.map((step, i) => (
                   <div key={i} className={`flex flex-col md:flex-row items-center gap-8 md:gap-16 ${i % 2 !== 0 ? 'md:flex-row-reverse' : ''}`}>
                     {/* Content */}
                     <motion.div 
                       initial={{ opacity: 0, x: i % 2 === 0 ? -50 : 50 }}
                       whileInView={{ opacity: 1, x: 0 }}
                       viewport={{ once: true, margin: "-100px" }}
                       className={`flex-1 ${i % 2 === 0 ? 'md:text-right' : 'md:text-left'} text-center md:text-left z-10 w-full`}
                     >
                        <div className={`text-6xl font-black text-transparent bg-clip-text bg-gradient-to-b ${step.color} opacity-30 mb-2`}>{step.step}</div>
                        <h4 className="text-3xl font-bold text-white mb-4 flex items-center justify-center md:justify-start gap-3 flex-row-reverse md:flex-row">
                          {i % 2 === 0 && <span className="hidden md:inline-block p-2 rounded-lg bg-white/5"><step.icon className="w-6 h-6 text-white"/></span>}
                          {step.title}
                          {i % 2 !== 0 && <span className="hidden md:inline-block p-2 rounded-lg bg-white/5"><step.icon className="w-6 h-6 text-white"/></span>}
                        </h4>
                        <p className="text-xl text-neutral-400 font-medium leading-relaxed">
                          {step.desc}
                        </p>
                     </motion.div>

                     {/* Center Node */}
                     <div className="hidden md:flex w-16 h-16 rounded-full bg-black border-4 border-black items-center justify-center z-10 relative">
                        <div className={`w-8 h-8 rounded-full bg-gradient-to-r ${step.color} flex items-center justify-center shadow-[0_0_20px_rgba(255,255,255,0.2)]`}>
                          <div className="w-3 h-3 bg-white rounded-full"></div>
                        </div>
                     </div>

                     {/* Visual Component */}
                     <motion.div 
                       initial={{ opacity: 0, scale: 0.9 }}
                       whileInView={{ opacity: 1, scale: 1 }}
                       viewport={{ once: true }}
                       className="flex-1 w-full max-w-md mx-auto"
                     >
                        {step.visual}
                     </motion.div>
                   </div>
                 ))}
               </div>
            </div>
          </div>
        </section>

        {/* FEATURE SECTIONS */}
        <section className="py-32 px-6 max-w-6xl mx-auto space-y-40">
          
          {/* WorkScore Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once:true }}>
              <h2 className="text-sm font-bold text-intern-sky tracking-widest uppercase mb-4">The Metric That Matters</h2>
              <h3 className="text-4xl md:text-5xl font-bold text-white mb-8">The Career Credit Score</h3>
              <div className="space-y-4 text-xl text-neutral-400 font-medium">
                <p>Anyone can claim skills.</p>
                <p>Few can prove them.</p>
                <div className="bg-white/5 border border-white/10 rounded-xl p-6 my-8 space-y-4">
                  <p className="text-white font-bold mb-4 border-b border-white/10 pb-4">WorkScore measures:</p>
                  <ul className="space-y-3">
                    <li className="flex items-center gap-3"><CheckCircle2 className="w-5 h-5 text-intern-success" /> Quality</li>
                    <li className="flex items-center gap-3"><CheckCircle2 className="w-5 h-5 text-intern-success" /> Reliability</li>
                    <li className="flex items-center gap-3"><CheckCircle2 className="w-5 h-5 text-intern-success" /> Consistency</li>
                    <li className="flex items-center gap-3"><CheckCircle2 className="w-5 h-5 text-intern-success" /> Delivery</li>
                  </ul>
                </div>
                <p>The more verified work you complete, the stronger your reputation becomes.</p>
              </div>
            </motion.div>
            <motion.div initial={{ opacity: 0, scale: 0.9 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once:true }} className="relative h-96 w-full flex items-center justify-center">
               <div className="absolute inset-0 bg-blue-500/10 rounded-full blur-3xl"></div>
               <div className="relative bg-[#0f172a] border border-white/10 rounded-[3rem] p-12 text-center shadow-2xl">
                 <Shield className="w-16 h-16 text-intern-sky mx-auto mb-6" />
                 <div className="text-8xl font-black text-white">842</div>
                 <div className="text-intern-sky tracking-widest uppercase font-bold mt-4 text-sm">WorkScore Level</div>
               </div>
            </motion.div>
          </div>

          {/* Honor Score & Verified Skills */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
            <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once:true }} className="bg-white/5 border border-white/10 rounded-3xl p-10">
              <h3 className="text-3xl font-bold text-white mb-6">Trust Matters</h3>
              <h4 className="text-intern-sky font-bold uppercase tracking-widest text-sm mb-6">Honor Score</h4>
              <div className="space-y-4 text-lg text-neutral-400 font-medium">
                <p>Honor Score tracks professionalism.</p>
                <ul className="space-y-2 py-4 border-y border-white/10">
                  <li className="text-white">Deliver on time.</li>
                  <li className="text-white">Communicate clearly.</li>
                  <li className="text-white">Complete what you start.</li>
                </ul>
                <p className="text-2xl font-bold text-white pt-4">Trust becomes visible.</p>
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once:true, margin: "-50px" }} transition={{ delay: 0.2 }} className="bg-white/5 border border-white/10 rounded-3xl p-10">
              <h3 className="text-3xl font-bold text-white mb-6">Skills Must Be Earned</h3>
              <h4 className="text-purple-400 font-bold uppercase tracking-widest text-sm mb-6">Verified Skills</h4>
              <div className="flex flex-wrap gap-3 mb-8">
                 <Badge variant="outline" className="text-sm py-2 px-4 border-intern-success text-intern-success bg-intern-success/10"><CheckCircle2 className="w-4 h-4 mr-2"/> React Verified</Badge>
                 <Badge variant="outline" className="text-sm py-2 px-4 border-intern-success text-intern-success bg-intern-success/10"><CheckCircle2 className="w-4 h-4 mr-2"/> Next.js Verified</Badge>
                 <Badge variant="outline" className="text-sm py-2 px-4 border-intern-success text-intern-success bg-intern-success/10"><CheckCircle2 className="w-4 h-4 mr-2"/> Python Verified</Badge>
                 <Badge variant="outline" className="text-sm py-2 px-4 border-intern-success text-intern-success bg-intern-success/10"><CheckCircle2 className="w-4 h-4 mr-2"/> UI/UX Verified</Badge>
              </div>
              <div className="space-y-4 text-lg text-neutral-400 font-medium">
                <p>Skills cannot be added manually.</p>
                <p>They must be unlocked through successful real-world work.</p>
              </div>
            </motion.div>
          </div>

          {/* Public Portfolio & Recruiter */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <motion.div initial={{ opacity: 0, x: -50 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once:true }} className="space-y-16">
              <div>
                <h3 className="text-3xl font-bold text-white mb-6">Every Task Becomes An Asset</h3>
                <h4 className="text-intern-sky font-bold uppercase tracking-widest text-sm mb-6">Public Portfolio</h4>
                <div className="space-y-4 text-lg text-neutral-400 font-medium">
                  <p>Every approved project becomes part of your permanent professional portfolio.</p>
                  <p className="text-white text-2xl font-bold pt-4">Not claims. Evidence.</p>
                </div>
              </div>

              <div className="pt-16 border-t border-white/10">
                <h3 className="text-3xl font-bold text-white mb-6">Hiring Through Evidence</h3>
                <h4 className="text-intern-success font-bold uppercase tracking-widest text-sm mb-6">For Recruiters</h4>
                <div className="space-y-4 text-lg text-neutral-400 font-medium">
                  <div className="flex gap-4 mb-6">
                    <span className="bg-white/10 rounded px-3 py-1 text-sm text-white">WorkScore</span>
                    <span className="bg-white/10 rounded px-3 py-1 text-sm text-white">Reliability</span>
                    <span className="bg-white/10 rounded px-3 py-1 text-sm text-white">Verified Skills</span>
                  </div>
                  <p>Recruiters can discover talent based on proven capability rather than resumes.</p>
                </div>
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 50 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once:true }} className="bg-[#0f172a] border border-white/10 rounded-3xl p-10 h-full flex flex-col justify-center">
              <h3 className="text-3xl font-bold text-white mb-6">Compete. Learn. Win.</h3>
              <h4 className="text-orange-400 font-bold uppercase tracking-widest text-sm mb-6 flex items-center gap-2"><Swords className="w-5 h-5"/> Competitive Mode</h4>
              <div className="space-y-4 text-lg text-neutral-400 font-medium pb-8 border-b border-white/10 mb-8">
                <p>For urgent tasks, multiple contributors can compete.</p>
                <div className="py-6 space-y-3">
                  <div className="flex items-center gap-4 bg-white/5 p-4 rounded-xl border border-white/10">
                    <div className="text-xl font-bold text-white w-6">1</div>
                    <div className="flex-1 text-white">Earns the reward.</div>
                  </div>
                  <div className="flex items-center gap-4 bg-white/5 p-4 rounded-xl border border-white/10 opacity-70">
                    <div className="text-xl font-bold text-white w-6">2</div>
                    <div className="flex-1 text-white">Earns recognition & XP.</div>
                  </div>
                  <div className="flex items-center gap-4 bg-white/5 p-4 rounded-xl border border-white/10 opacity-50">
                    <div className="text-xl font-bold text-white w-6">3</div>
                    <div className="flex-1 text-white">Earns certificates & XP.</div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>

        </section>

        {/* WHY WE EXIST */}
        <section className="py-32 px-6 bg-[#03060c] text-center border-t border-white/5">
          <motion.div initial={{ opacity:0, scale:0.95 }} whileInView={{ opacity:1, scale:1 }} viewport={{ once:true }} className="max-w-4xl mx-auto">
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-12 leading-tight">
              The Current System Rewards Credentials.<br/>
              <span className="text-intern-sky">We Reward Contribution.</span>
            </h2>
            
            <div className="text-xl md:text-2xl text-neutral-400 space-y-6 font-medium mb-16">
              <p>Degrees matter.</p>
              <p>Certificates matter.</p>
              <p className="text-3xl text-white font-bold my-8">But real work matters more.</p>
              <p>InternLoop exists to build a world where opportunities are earned through demonstrated ability.</p>
            </div>
          </motion.div>
        </section>

        {/* FINAL STATEMENT */}
        <section className="min-h-screen flex flex-col items-center justify-center px-6 bg-black text-center relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-intern-blue/10 to-black pointer-events-none" />
          
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
            className="z-10 max-w-5xl w-full"
          >
            <h2 className="text-6xl md:text-9xl md:leading-tight font-black text-white mb-16">
              Your Future Should Be Built.
              <span className="block text-transparent bg-clip-text bg-gradient-to-b from-neutral-400 to-neutral-800">Not Claimed.</span>
            </h2>
            
            <div className="text-2xl md:text-4xl text-neutral-400 font-bold space-y-6 mb-20 text-left md:text-center w-max mx-auto md:w-full">
              <p>Start building reputation.</p>
              <p>Start building proof.</p>
              <p className="text-white text-5xl !mt-8">Start building your future.</p>
            </div>
            
            <Button onClick={onStart} size="lg" className="h-16 px-12 text-xl rounded-full bg-intern-sky text-black hover:bg-intern-blue hover:scale-105 transition-all shadow-[0_0_40px_rgba(56,189,248,0.4)]">
              Start Your Journey
            </Button>
          </motion.div>
        </section>

      </main>
    </div>
  );
}
