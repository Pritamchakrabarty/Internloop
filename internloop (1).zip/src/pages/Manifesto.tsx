import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import { ArrowRight, Box, ShieldCheck, Target, Zap, LayoutDashboard, Database, Link as LinkIcon, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Manifesto({ onBack, onStart }: { onBack: () => void, onStart: () => void }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: containerRef });
  
  return (
    <div ref={containerRef} className="bg-black text-white min-h-screen selection:bg-intern-sky selection:text-black font-sans relative overflow-x-hidden">
      
      {/* Dynamic Background Mesh */}
      <div className="fixed inset-0 z-0 pointer-events-none opacity-40">
        <div className="absolute top-[-10%] left-[-10%] w-[40vw] h-[40vw] rounded-full bg-intern-blue/20 blur-[120px] mix-blend-screen animate-pulse duration-10000" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50vw] h-[50vw] rounded-full bg-purple-900/20 blur-[150px] mix-blend-screen animate-pulse duration-7000" />
      </div>

      <nav className="fixed top-0 left-0 right-0 z-50 px-6 py-6 flex justify-between items-center backdrop-blur-md bg-black/50 border-b border-white/5 transition-all">
        <button onClick={onBack} className="text-xl font-bold flex items-center gap-2 group">
          <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-black font-black rotate-3 group-hover:rotate-0 transition-transform">
            i
          </div>
          <span className="tracking-tight">InternLoop</span>
        </button>
        <div className="hidden md:flex gap-8 items-center text-sm font-medium">
          <div className="text-white">Manifesto</div>
          <Button onClick={onStart} className="bg-white text-black hover:bg-neutral-200 hover:scale-105 transition-all rounded-full px-6">
            Explore Opportunities
          </Button>
        </div>
      </nav>

      <main className="relative z-10">
        {/* HERO SECTION */}
        <section className="min-h-screen flex flex-col justify-center items-center px-6 pt-32 text-center relative overflow-hidden">
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            className="max-w-5xl mx-auto z-10"
          >
            <h1 className="text-6xl md:text-8xl font-bold tracking-tight leading-[1.1] mb-8">
              Resumes Don't<br className="hidden md:block"/> Build Careers.
              <span className="block mt-2 bg-gradient-to-r from-intern-sky via-purple-400 to-intern-blue bg-clip-text text-transparent">Work Does.</span>
            </h1>
            
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 1 }}
              className="text-xl md:text-2xl text-neutral-400 max-w-2xl mx-auto space-y-4 mb-12 font-medium"
            >
              <p>The world rewards credentials.</p>
              <p className="text-white">We believe it should reward proof.</p>
              <p className="text-lg text-neutral-500 mt-6 !leading-relaxed">
                InternLoop exists to create a future where opportunities are earned through demonstrated ability, not claimed through bullet points.
              </p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8, duration: 0.8 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Button onClick={onStart} size="lg" className="h-14 px-8 text-lg rounded-full bg-white text-black hover:bg-neutral-200">
                Start Building Your Reputation <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </motion.div>
          </motion.div>

          {/* Floating Elements */}
          <div className="absolute inset-0 pointer-events-none z-0 hidden lg:block perspective-1000">
            <motion.div 
              animate={{ y: [0, -30, 0], rotateX: [10, 0, 10], rotateY: [-10, 0, -10] }}
              transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
              className="absolute left-[10%] top-[30%] w-64 p-4 rounded-xl bg-[#0f172a]/80 backdrop-blur-xl border border-white/10 shadow-2xl"
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 rounded bg-intern-success/20 flex items-center justify-center"><CheckCircle2 className="w-4 h-4 text-intern-success"/></div>
                <div className="text-sm font-bold">Task Evaluated</div>
              </div>
              <div className="h-2 w-3/4 bg-white/10 rounded mb-2"></div>
              <div className="h-2 w-1/2 bg-white/10 rounded text-intern-sky text-xs font-mono pt-2">AI Score: 98/100</div>
            </motion.div>
            
            <motion.div 
              animate={{ y: [0, 40, 0], rotateX: [-10, 0, -10], rotateY: [10, 0, 10] }}
              transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
              className="absolute right-[10%] top-[40%] w-72 p-5 rounded-2xl bg-[#081225]/80 backdrop-blur-xl border border-white/10 shadow-2xl"
            >
              <div className="text-xs text-muted-foreground mb-1">WorkScore Level</div>
              <div className="text-4xl font-black text-white">842</div>
              <div className="mt-4 h-1 w-full bg-white/10 rounded overflow-hidden">
                <div className="h-full bg-gradient-to-r from-intern-blue to-purple-500 w-[84%]"></div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* THE PROBLEM SECTION */}
        <section className="py-32 px-6 bg-black relative">
          <div className="max-w-4xl mx-auto border-l border-white/10 pl-8 md:pl-16 relative">
            <div className="absolute -left-[1px] top-0 bottom-0 w-[2px] bg-gradient-to-b from-transparent via-red-500/50 to-transparent scale-y-0 transform origin-top transition-transform duration-1000 group-hover:scale-y-100" />
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-4xl md:text-6xl font-bold mb-12 text-white">The Resume Is Broken.</h2>
              <div className="space-y-8 text-xl md:text-2xl text-neutral-400 leading-relaxed font-medium">
                <p>Millions of talented people are overlooked because they lack <span className="text-white">experience.</span></p>
                <p>Millions of experienced people are overlooked because they lack the right <span className="text-white">credentials.</span></p>
                
                <div className="py-8 my-8 border-y border-white/5 space-y-4">
                  <p className="text-3xl text-white font-bold">Resumes tell stories.</p>
                  <p className="text-3xl text-intern-sky font-bold">Work reveals truth.</p>
                </div>
                
                <p>Today people spend years collecting certificates and degrees.</p>
                <p>Yet employers still ask:</p>
                <p className="text-3xl text-white italic">"Can you actually do the work?"</p>
                
                <p className="pt-8 text-neutral-500">The current system rewards claims. Not proof.</p>
              </div>
            </motion.div>
          </div>
        </section>

        {/* THE VISION SECTION */}
        <section className="py-32 px-6 bg-[#080c16] relative overflow-hidden">
          <div className="absolute top-0 right-0 w-full h-full bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-intern-blue/10 via-black to-black opacity-50" />
          
          <div className="max-w-4xl mx-auto relative z-10 text-center">
            <motion.h2 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-4xl md:text-6xl font-bold mb-16 text-white"
            >
              Imagine A World Where Work<br/> Speaks For Itself.
            </motion.h2>
            
            <div className="space-y-6 text-xl md:text-2xl text-neutral-300 font-medium text-left max-w-2xl mx-auto">
              <p className="text-neutral-500">Imagine a profile that doesn't say:</p>
              <p className="line-through decoration-red-500/50 decoration-2 text-white">"I know React."</p>
              <p className="text-neutral-500 pt-4">Instead it says:</p>
              
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-white/5 border border-white/10 rounded-2xl p-6 md:p-8 backdrop-blur-sm my-8"
              >
                <ul className="space-y-4 text-intern-sky font-bold text-2xl">
                  <li className="flex items-center gap-3"><CheckCircle2 className="text-intern-success w-6 h-6"/> Completed 42 React projects.</li>
                  <li className="flex items-center gap-3"><Target className="text-intern-success w-6 h-6"/> 97% approval rate.</li>
                  <li className="flex items-center gap-3"><ShieldCheck className="text-intern-success w-6 h-6"/> Verified by independent evaluators.</li>
                </ul>
              </motion.div>

              <div className="space-y-6 pt-8">
                <p>Imagine recruiters hiring based on demonstrated capability.</p>
                <p>Imagine students building careers before graduation.</p>
                <p className="text-3xl text-white font-bold">Imagine reputation being earned, not claimed.</p>
              </div>
              
              <p className="pt-8 text-neutral-500">That is the future we are building.</p>
            </div>
          </div>
        </section>

        {/* THE PRINCIPLES */}
        <section className="py-32 px-6 max-w-7xl mx-auto">
          <div className="mb-20">
            <h2 className="text-sm font-bold text-intern-sky tracking-widest uppercase mb-4">The InternLoop Principle</h2>
            <h3 className="text-4xl md:text-5xl font-bold text-white">Our Core Tenets</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              { title: "Work Over Words", desc: "Proof beats promises.", icon: Zap },
              { title: "Reputation Over Resumes", desc: "Your history matters more than your claims.", icon: Database },
              { title: "Opportunity Through Merit", desc: "Talent should be discoverable regardless of background.", icon: Target },
              { title: "Learn By Building", desc: "The fastest way to grow is through real work.", icon: Box },
              { title: "Trust Through Verification", desc: "Every achievement should be verifiable.", icon: ShieldCheck }
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className={`p-10 rounded-3xl bg-[#0a0a0a] border border-white/5 hover:border-intern-blue/30 transition-colors group ${i === 4 ? 'md:col-span-2 text-center md:flex flex-col items-center' : ''}`}
              >
                <item.icon className={`w-10 h-10 text-intern-sky mb-6 group-hover:scale-110 transition-transform ${i === 4 ? 'mx-auto' : ''}`} />
                <h4 className="text-2xl font-bold text-white mb-2">{item.title}</h4>
                <p className="text-neutral-400 text-lg">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* THE WORKSCORE SECTION */}
        <section className="py-32 px-6 bg-gradient-to-b from-black to-[#050B14] relative border-t border-white/5">
          <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-sm font-bold text-intern-sky tracking-widest uppercase mb-4">The WorkScore</h2>
              <h3 className="text-4xl md:text-6xl font-bold mb-8 text-white">Your Career<br/> Credit Score</h3>
              
              <div className="space-y-6 text-xl text-neutral-400 font-medium pb-8 border-b border-white/10 mb-8">
                <p>GitHub measures code.</p>
                <p>LinkedIn measures connections.</p>
                <p className="text-white font-bold">InternLoop measures impact.</p>
              </div>
              
              <div className="space-y-4 text-lg text-neutral-300">
                <p>WorkScore represents verified contribution.</p>
                <p>Every completed task strengthens your reputation.</p>
                <p>Every successful project builds trust.</p>
                <p>Every challenge completed creates opportunity.</p>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="relative aspect-square w-full max-w-md mx-auto"
            >
              <div className="absolute inset-0 bg-gradient-to-tr from-intern-blue/20 to-purple-500/20 rounded-full blur-3xl mix-blend-screen animate-pulse duration-3000"></div>
              <div className="absolute inset-4 rounded-[3rem] border border-white/10 bg-[#0f172a]/90 backdrop-blur-2xl flex flex-col items-center justify-center shadow-2xl overflow-hidden p-8">
                 <div className="w-full flex justify-between items-center mb-12">
                   <span className="text-sm text-neutral-400">Pritam K.</span>
                   <ShieldCheck className="w-5 h-5 text-intern-success" />
                 </div>
                 
                 <svg className="w-64 h-64 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 rotate-180" viewBox="0 0 100 100">
                    <circle cx="50" cy="50" r="40" fill="transparent" stroke="rgba(255,255,255,0.05)" strokeWidth="8" strokeDasharray="125 250" strokeLinecap="round" />
                    <circle cx="50" cy="50" r="40" fill="transparent" stroke="url(#gradient)" strokeWidth="8" strokeDasharray="90 250" strokeLinecap="round" className="animate-[dash_3s_ease-out_forwards]" />
                    <defs>
                      <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#38bdf8" />
                        <stop offset="100%" stopColor="#a855f7" />
                      </linearGradient>
                    </defs>
                 </svg>
                 
                 <div className="relative z-10 text-center mt-[-20px]">
                    <div className="text-7xl font-black text-transparent bg-clip-text bg-gradient-to-b from-white to-neutral-500">842</div>
                    <div className="text-sm font-bold text-intern-sky tracking-widest mt-2 uppercase">WorkScore</div>
                 </div>

                 <div className="w-full mt-auto space-y-3">
                   <div className="flex justify-between text-xs font-mono text-neutral-400 bg-black/50 p-2 rounded">
                     <span>TASKS_COMPLETED</span>
                     <span className="text-white">42</span>
                   </div>
                   <div className="flex justify-between text-xs font-mono text-neutral-400 bg-black/50 p-2 rounded">
                     <span>APPROVAL_RATE</span>
                     <span className="text-intern-success">98.5%</span>
                   </div>
                 </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* AUDIENCE SECTIONS */}
        <section className="py-32 px-6 max-w-5xl mx-auto space-y-32">
          {/* For Students */}
          <motion.div initial={{ opacity:0, y: 50 }} whileInView={{ opacity:1, y: 0 }} viewport={{ once:true }} className="border-l-4 border-intern-sky pl-8">
            <h2 className="text-intern-sky font-bold uppercase tracking-widest mb-4">For Students & Beginners</h2>
            <h3 className="text-4xl md:text-5xl font-bold text-white mb-8">Stop Waiting For Experience.<br/>Start Creating It.</h3>
            <div className="text-xl text-neutral-400 space-y-4 max-w-2xl">
              <p>You don't need permission.</p>
              <p>You don't need connections.</p>
              <p>You don't need a perfect resume.</p>
              <p className="text-white font-bold my-6">You need proof.</p>
              <p>InternLoop gives you a place to earn it.</p>
            </div>
          </motion.div>

          {/* For Professionals */}
          <motion.div initial={{ opacity:0, y: 50 }} whileInView={{ opacity:1, y: 0 }} viewport={{ once:true }} className="border-l-4 border-purple-500 pl-8 md:ml-20">
            <h2 className="text-purple-400 font-bold uppercase tracking-widest mb-4">For Professionals</h2>
            <h3 className="text-4xl md:text-5xl font-bold text-white mb-8">Turn Overload Into Opportunity.</h3>
            <div className="text-xl text-neutral-400 space-y-4 max-w-2xl">
              <p>Every day professionals are buried under deadlines.</p>
              <p>Every unfinished task is an opportunity for someone else to grow.</p>
              <div className="mt-8 space-y-2 text-white font-medium">
                <p>Delegate intelligently.</p>
                <p>Create opportunities.</p>
                <p>Move faster.</p>
              </div>
            </div>
          </motion.div>

          {/* For Recruiters */}
          <motion.div initial={{ opacity:0, y: 50 }} whileInView={{ opacity:1, y: 0 }} viewport={{ once:true }} className="border-l-4 border-intern-success pl-8">
            <h2 className="text-intern-success font-bold uppercase tracking-widest mb-4">For Recruiters & Hiring Managers</h2>
            <h3 className="text-4xl md:text-5xl font-bold text-white mb-8">Hire Through Evidence.</h3>
            <div className="text-xl text-neutral-400 space-y-4 max-w-2xl">
              <p>Resumes can be written.</p>
              <p>Skills can be claimed.</p>
              <p>Experience can be exaggerated.</p>
              <p className="text-white font-bold my-6 text-3xl">Work cannot.</p>
              <p>Discover talent through real, verified achievements.</p>
            </div>
          </motion.div>
        </section>

        {/* THE FUTURE */}
        <section className="py-32 px-6 bg-[#03060c] text-center">
          <motion.div initial={{ opacity:0, scale:0.95 }} whileInView={{ opacity:1, scale:1 }} viewport={{ once:true }} className="max-w-4xl mx-auto">
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-12">Building The World's Largest<br/> Proof-of-Work Network</h2>
            
            <div className="text-xl md:text-2xl text-neutral-400 space-y-6 font-medium mb-16">
              <p>We envision a future where:</p>
              <ul className="space-y-4 text-white text-left max-w-lg mx-auto list-disc pl-5">
                <li>Students build careers before graduation</li>
                <li>Reputation replaces resumes</li>
                <li>Skills are verified through action</li>
                <li>Opportunities are earned through contribution</li>
                <li>Talent becomes globally discoverable</li>
              </ul>
            </div>
            
            <p className="text-2xl text-neutral-500 font-bold mb-4">InternLoop is not building another job board.</p>
            <p className="text-3xl text-intern-sky font-black">We are building a new professional identity system.</p>
          </motion.div>
        </section>

        {/* FINAL STATEMENT */}
        <section className="min-h-screen flex flex-col items-center justify-center px-6 bg-black text-center relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white/5 to-black pointer-events-none" />
          
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
            className="z-10 max-w-5xl w-full"
          >
            <h2 className="text-6xl md:text-8xl md:leading-tight font-black text-transparent bg-clip-text bg-gradient-to-b from-white to-neutral-600 mb-16">
              The Future Belongs<br/> To Builders.
            </h2>
            
            <div className="text-2xl md:text-4xl text-neutral-500 font-bold space-y-6 mb-20">
              <p>Not those who claim.</p>
              <p>Not those who boast.</p>
              <p>Not those who collect credentials.</p>
              <div className="py-8 space-y-6 text-white bg-clip-text bg-gradient-to-r from-intern-sky to-purple-500">
                <p>But those who create.</p>
                <p>Those who solve.</p>
                <p>Those who contribute.</p>
                <p className="text-5xl md:text-7xl !mt-12 text-white">Those who build.</p>
              </div>
            </div>
            
            <h3 className="text-3xl font-medium text-white mb-12">Welcome to InternLoop.</h3>
            
            <Button onClick={onStart} size="lg" className="h-16 px-12 text-xl rounded-full bg-white text-black hover:bg-neutral-200 hover:scale-105 transition-all">
              Join The Network
            </Button>
          </motion.div>
        </section>

      </main>
    </div>
  );
}
