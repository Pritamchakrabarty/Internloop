import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface TermsProps {
  onBack: () => void;
}

export default function TermsAndConditions({ onBack }: TermsProps) {
  return (
    <div className="flex min-h-screen flex-col bg-background relative overflow-hidden text-white px-6 py-12">
      <div className="max-w-4xl mx-auto w-full relative z-10 glass-panel p-8 md:p-12 rounded-2xl">
        <Button variant="ghost" onClick={onBack} className="mb-8 hover:bg-white/5 text-muted-foreground hover:text-white -ml-4">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <h1 className="text-4xl font-bold mb-8">Terms and Conditions for Internloop</h1>

        <div className="space-y-6 text-muted-foreground leading-relaxed">
          <p>By accessing our website, you agree to these terms.</p>
          
          <h2 className="text-2xl font-bold text-white mt-8 mb-4">Use of Service</h2>
          <p>You agree to use Internloop services only for lawful purposes.</p>
          
          <h2 className="text-2xl font-bold text-white mt-8 mb-4">Intellectual Property</h2>
          <p>All content on this website is owned by Internloop and cannot be copied without permission.</p>
          
          <h2 className="text-2xl font-bold text-white mt-8 mb-4">Limitation of Liability</h2>
          <p>Internloop is not responsible for any damages arising from use of our services.</p>
          
          <h2 className="text-2xl font-bold text-white mt-8 mb-4">Contact</h2>
          <p>For queries: +91 9827746174</p>
        </div>
      </div>
    </div>
  );
}
