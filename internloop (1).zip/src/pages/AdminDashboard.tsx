import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, 
  BarChart3, 
  UsersRound, 
  Settings2,
  AlertOctagon
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import SettingsModal from '@/src/components/SettingsModal';
import NotificationCenter from '@/src/components/NotificationCenter';

interface AdminDashboardProps {
  onNavigate: () => void;
}

const recentActivity = [
  { id: 1, event: "New Publisher Registered", detail: "Amazon India", time: "2m ago" },
  { id: 2, event: "Dispute Raised", detail: "Task #4592 - Pritam K.", time: "15m ago" },
  { id: 3, event: "Payout Processed", detail: "₹1,200 to Rahul M.", time: "1h ago" }
];

export default function AdminDashboard({ onNavigate }: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [pendingPublishers, setPendingPublishers] = useState<any[]>([]);
  const [usersList, setUsersList] = useState<any[]>([]);
  const [disputesList, setDisputesList] = useState<any[]>([]);
  const [isApproving, setIsApproving] = useState<string | null>(null);
  
  const [metrics, setMetrics] = useState({
    totalUsers: 8245,
    activeTasks: 0,
    totalVolume: '₹2.4M',
    openDisputes: 4,
    totalApplications: 0,
    approvedApplications: 0,
  });

  useEffect(() => {
    const fetchMetrics = async () => {
      try {
        const res = await fetch('/api/admin/metrics', { headers: { 'Authorization': `Bearer ${localStorage.getItem('auth_token')}` } });
        if (res.status === 401 || res.status === 403) {
           onNavigate();
           return;
        }
        const data = await res.json();
        setMetrics(prev => ({
          ...prev,
          activeTasks: data.totalTasks,
          totalApplications: data.totalApplications,
          approvedApplications: data.approvedApplications
        }));
      } catch (e) {}
    };

    const fetchPendingPublishers = async () => {
       try {
         const res = await fetch('/api/admin/pending-publishers', { headers: { 'Authorization': `Bearer ${localStorage.getItem('auth_token')}` } });
         if (res.ok) {
           const data = await res.json();
           setPendingPublishers(data);
         }
       } catch (e) {}
    };

    const fetchDirectory = async () => {
       try {
         const [uRes, dRes] = await Promise.all([
            fetch('/api/admin/users', { headers: { 'Authorization': `Bearer ${localStorage.getItem('auth_token')}` } }),
            fetch('/api/admin/disputes', { headers: { 'Authorization': `Bearer ${localStorage.getItem('auth_token')}` } })
         ]);
         if (uRes.ok) setUsersList(await uRes.json());
         if (dRes.ok) setDisputesList(await dRes.json());
       } catch (e) {}
    };

    fetchMetrics();
    fetchPendingPublishers();
    fetchDirectory();
    const inv = setInterval(() => {
       fetchMetrics();
       fetchPendingPublishers();
       fetchDirectory();
    }, 5000);
    return () => clearInterval(inv);
  }, []);

  const handleProcessPublisher = async (id: number, action: 'approve' | 'reject') => {
      setIsApproving(id.toString() + action);
      try {
        const res = await fetch('/api/admin/approve-publisher', {
           method: 'POST',
           headers: {
             'Content-Type': 'application/json',
             'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
           },
           body: JSON.stringify({ id, action })
        });
        if (res.ok) {
           setPendingPublishers(prev => prev.filter(p => p.id !== id));
        }
      } catch (e) {
         console.error("Failed to process", e);
      } finally {
         setIsApproving(null);
      }
  };

  return (
    <div className="flex h-screen bg-[#020617] overflow-hidden text-foreground">
      <SettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} onLogout={onNavigate} />
      
      {/* Sidebar */}
      <aside className="w-64 border-r border-white/5 bg-[#081225]/80 backdrop-blur-xl flex flex-col pt-6 hidden md:flex z-20">
        <div className="px-6 mb-8 cursor-pointer" onClick={onNavigate}>
           <div className="flex items-center space-x-3">
             <img src="/logo.png" alt="InternLoop" className="h-[32px] w-auto object-contain rounded-md" />
             <Badge className="bg-red-500/20 text-red-500 hover:bg-red-500/20 border-0">Admin</Badge>
           </div>
        </div>
        
        <nav className="flex-1 px-4 space-y-2">
          {[
            { id: 'overview', icon: BarChart3, label: 'Platform Metrics' },
            { id: 'approvals', icon: UsersRound, label: 'Publisher Approvals' },
            { id: 'users', icon: UsersRound, label: 'User Directory' },
            { id: 'disputes', icon: ShieldAlert, label: 'Resolution Center' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                activeTab === item.id 
                  ? 'bg-white/10 text-white' 
                  : 'text-muted-foreground hover:text-white hover:bg-white/5'
              }`}
            >
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-white/5">
          <button 
            onClick={() => setIsSettingsOpen(true)}
            className="w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium text-muted-foreground hover:text-white hover:bg-white/5 transition-colors"
          >
            <Settings2 className="w-5 h-5" />
            <span>Sys Config</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative z-20 overflow-y-auto">
        <header className="h-16 border-b border-white/5 flex items-center justify-between px-8 bg-black/20 sticky top-0 backdrop-blur-sm z-30">
          <h1 className="text-xl font-bold text-white tracking-tight">Admin Console</h1>
          <NotificationCenter />
        </header>

        <div className="p-8 max-w-6xl mx-auto w-full">
          {activeTab === 'overview' && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="glass-panel p-6 rounded-2xl border border-white/5">
                  <p className="text-sm font-medium text-muted-foreground mb-4">Total Users</p>
                  <h3 className="text-3xl font-bold text-white">{metrics.totalUsers}</h3>
                  <p className="text-xs text-intern-success mt-2">+12% this week</p>
                </div>
                <div className="glass-panel p-6 rounded-2xl border border-white/5 relative">
                  <p className="text-sm font-medium text-muted-foreground mb-4">Active Tasks</p>
                  <h3 className="text-3xl font-bold text-white">{metrics.activeTasks}</h3>
                  <div className="absolute right-0 top-0 w-24 h-24 bg-green-500/10 rounded-full blur-2xl -mr-6 -mt-6 pointer-events-none" />
                </div>
                <div className="glass-panel p-6 rounded-2xl border border-white/5 relative">
                  <p className="text-sm font-medium text-muted-foreground mb-4">Live Submissions</p>
                  <h3 className="text-3xl font-bold text-white">{metrics.totalApplications}</h3>
                  <p className="text-xs text-intern-sky mt-2">{metrics.approvedApplications} approved</p>
                </div>
                <div className="glass-panel p-6 rounded-2xl border border-red-500/20 bg-red-500/5 relative">
                  <div className="flex justify-between items-start mb-4">
                     <p className="text-sm font-medium text-red-500">Open Disputes</p>
                     <AlertOctagon className="w-5 h-5 text-red-500" />
                  </div>
                  <h3 className="text-3xl font-bold text-white">{metrics.openDisputes}</h3>
                  <p className="text-xs text-red-400 mt-2">Requires immediate action</p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-xl font-bold text-white mb-6">Recent System Activity</h3>
                  <div className="glass-panel border-white/5 rounded-2xl p-6">
                    <div className="space-y-6">
                      {recentActivity.map(activity => (
                        <div key={activity.id} className="flex items-start justify-between">
                           <div>
                             <p className="font-medium text-white">{activity.event}</p>
                             <p className="text-sm text-muted-foreground mt-1">{activity.detail}</p>
                           </div>
                           <span className="text-xs font-medium text-muted-foreground bg-white/5 px-2 py-1 rounded">{activity.time}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'approvals' && (
            <div className="space-y-6 animate-in fade-in duration-500">
               <div className="flex justify-between items-center mb-4">
                 <div>
                   <h2 className="text-2xl font-bold text-white">Publisher Approvals</h2>
                   <p className="text-muted-foreground">Review and verify new publisher accounts.</p>
                 </div>
               </div>

               {pendingPublishers.length === 0 ? (
                 <div className="glass-panel p-12 text-center rounded-2xl border border-white/5">
                   <p className="text-muted-foreground">No pending publishers.</p>
                 </div>
               ) : (
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                   {pendingPublishers.map(pub => (
                     <div key={pub.id} className="glass-panel p-6 rounded-2xl border border-white/5 relative overflow-hidden group">
                       <div className="absolute inset-0 bg-gradient-to-br from-intern-blue/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                       <div className="relative z-10">
                         <h3 className="text-xl font-bold text-white truncate mb-1">{pub.identifier}</h3>
                         <p className="text-sm text-muted-foreground mb-6">Signed up: {new Date(pub.createdAt).toLocaleDateString()}</p>
                         
                         <div className="flex space-x-3 mt-auto">
                           <button 
                             onClick={() => handleProcessPublisher(pub.id, 'approve')}
                             disabled={isApproving !== null}
                             className="flex-1 bg-intern-success hover:bg-intern-success/90 text-white py-2 rounded-xl text-sm font-medium transition-all"
                           >
                             {isApproving === `${pub.id}approve` ? '...' : 'Approve'}
                           </button>
                           <button 
                             onClick={() => handleProcessPublisher(pub.id, 'reject')}
                             disabled={isApproving !== null}
                             className="flex-1 bg-white/5 hover:bg-red-500/20 text-white hover:text-red-500 border border-white/10 hover:border-red-500/30 py-2 rounded-xl text-sm font-medium transition-all"
                           >
                             {isApproving === `${pub.id}reject` ? '...' : 'Reject'}
                           </button>
                         </div>
                       </div>
                     </div>
                   ))}
                 </div>
               )}
            </div>
          )}
           {activeTab === 'users' && (
            <div className="space-y-6 animate-in fade-in duration-500">
               <div className="flex justify-between items-center mb-4">
                 <div>
                   <h2 className="text-2xl font-bold text-white">User Directory</h2>
                   <p className="text-muted-foreground">Manage platform users across all roles.</p>
                 </div>
               </div>

               <div className="glass-panel p-6 rounded-2xl border border-white/5 overflow-x-auto">
                 <table className="w-full text-left border-collapse">
                   <thead>
                     <tr className="border-b border-white/10 text-muted-foreground text-sm">
                       <th className="pb-3 font-medium">User ID</th>
                       <th className="pb-3 font-medium">Role</th>
                       <th className="pb-3 font-medium">Joined</th>
                     </tr>
                   </thead>
                   <tbody>
                     {usersList.length === 0 ? (
                       <tr>
                         <td colSpan={3} className="py-8 text-center text-muted-foreground">No users found.</td>
                       </tr>
                     ) : (
                       usersList.map((user) => (
                         <tr key={user.id} className="border-b border-white/5 last:border-0 hover:bg-white/5 transition-colors">
                           <td className="py-4 text-white">{user.identifier}</td>
                           <td className="py-4">
                             <Badge variant={
                               user.role === 'admin' ? 'destructive' :
                               user.role === 'publisher' ? 'default' :
                               user.role === 'evaluator' ? 'secondary' : 'outline'
                             } className="capitalize">
                               {user.role}
                             </Badge>
                           </td>
                           <td className="py-4 text-muted-foreground">{new Date(user.createdAt || Date.now()).toLocaleDateString()}</td>
                         </tr>
                       ))
                     )}
                   </tbody>
                 </table>
               </div>
            </div>
           )}

           {activeTab === 'disputes' && (
            <div className="space-y-6 animate-in fade-in duration-500">
               <div className="flex justify-between items-center mb-4">
                 <div>
                   <h2 className="text-2xl font-bold text-white">Resolution Center</h2>
                   <p className="text-muted-foreground">Review and resolve platform disputes.</p>
                 </div>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 {disputesList.length === 0 ? (
                    <div className="col-span-full glass-panel p-12 text-center rounded-2xl border border-white/5">
                      <p className="text-muted-foreground">No active disputes.</p>
                    </div>
                 ) : (
                    disputesList.map(dispute => (
                      <div key={dispute.id} className="glass-panel p-6 rounded-2xl border border-white/5 relative overflow-hidden">
                        <div className="flex justify-between items-start mb-4">
                          <h3 className="text-lg font-bold text-white">{dispute.type}</h3>
                          <Badge variant="destructive" className="capitalize">{dispute.status}</Badge>
                        </div>
                        <p className="text-muted-foreground mb-4">{dispute.description}</p>
                        <div className="flex justify-between items-center text-sm">
                           <span className="text-white/60">{dispute.user}</span>
                           <span className="text-white/40">{new Date(dispute.date).toLocaleDateString()}</span>
                        </div>
                        <div className="mt-6 pt-4 border-t border-white/10 flex space-x-3">
                           <button className="flex-1 bg-white/10 hover:bg-white/20 text-white py-2 rounded-xl text-sm font-medium transition-all">
                             Investigate
                           </button>
                           <button className="flex-1 bg-intern-success/20 hover:bg-intern-success/30 text-intern-success border border-intern-success/30 py-2 rounded-xl text-sm font-medium transition-all">
                             Resolve
                           </button>
                        </div>
                      </div>
                    ))
                 )}
               </div>
            </div>
           )}
        </div>
      </main>
    </div>
  );
}
