import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  PlusCircle, 
  Users, 
  Wallet,
  Settings,
  MoreVertical,
  CheckCircle2,
  XCircle,
  Eye,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import FundingModal from '@/src/components/FundingModal';
import SettingsModal from '@/src/components/SettingsModal';
import NotificationCenter from '@/src/components/NotificationCenter';
import { toast } from 'sonner';

interface PublisherDashboardProps {
  onNavigate: () => void;
}

interface Application {
  id: string;
  taskId: string;
  taskTitle: string;
  intern: string;
  status: string;
  aiScore?: number;
  proofUrl?: string;
}

export default function PublisherDashboard({ onNavigate }: PublisherDashboardProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [isFundingOpen, setIsFundingOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const [applications, setApplications] = useState<Application[]>([]);
  const [isPublishing, setIsPublishing] = useState(false);
  const [newTask, setNewTask] = useState({ title: '', reward: '', description: '' });

  const publisherName = "Cloud Systems Inc.";

  const fetchApplications = async () => {
    try {
      const res = await fetch('/api/applications', { headers: { 'Authorization': `Bearer ${localStorage.getItem('auth_token')}` } });
      const data = await res.json();
      setApplications(data);
    } catch(e) {}
  };

  useEffect(() => {
    fetchApplications();
    const interval = setInterval(fetchApplications, 5000);
    return () => clearInterval(interval);
  }, []);

  const handlePublish = async () => {
    if(!newTask.title || !newTask.reward || !newTask.description) {
      toast.error("Please fill all fields"); return;
    }
    setIsPublishing(true);
    try {
      const res = await fetch('/api/tasks', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('auth_token')}` },
        body: JSON.stringify({ ...newTask, publisher: publisherName })
      });
      if (!res.ok) throw new Error();
      toast.success("Task published successfully!");
      setNewTask({ title: '', reward: '', description: '' });
      setActiveTab('overview');
    } catch(e) {
      toast.error("Failed to publish task");
    } finally {
      setIsPublishing(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'approved': return <Badge variant="outline" className="border-intern-success/30 text-intern-success bg-intern-success/10">Evaluator Approved</Badge>;
      case 'rejected': return <Badge variant="outline" className="border-red-500/30 text-red-500">Evaluator Rejected</Badge>;
      case 'evaluating_ai': return <Badge variant="outline" className="border-intern-sky/30 text-intern-sky animate-pulse">AI Checking</Badge>;
      case 'pending_human': return <Badge variant="outline" className="border-yellow-500/30 text-yellow-500">Human Pending</Badge>;
      default: return <Badge variant="outline" className="border-white/20 text-muted-foreground">{status}</Badge>;
    }
  };

  return (
    <div className="flex h-screen bg-[#020617] overflow-hidden text-foreground">
      <FundingModal isOpen={isFundingOpen} onClose={() => setIsFundingOpen(false)} />
      <SettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} onLogout={onNavigate} />
      
      {/* Sidebar */}
      <aside className="w-64 border-r border-white/5 bg-[#081225]/80 backdrop-blur-xl flex flex-col pt-6 hidden md:flex z-20">
        <div className="px-6 mb-8 cursor-pointer" onClick={onNavigate}>
           <div className="flex items-center space-x-3">
             <img src="/logo.png" alt="InternLoop" className="h-[32px] w-auto object-contain rounded-md" />
             <Badge className="bg-intern-blue/20 text-intern-sky hover:bg-intern-blue/20 border-0">Publisher</Badge>
           </div>
        </div>
        
        <nav className="flex-1 px-4 space-y-2">
          {[
            { id: 'overview', icon: LayoutDashboard, label: 'Overview' },
            { id: 'tasks', icon: PlusCircle, label: 'Post a Task' },
            { id: 'applicants', icon: Users, label: 'Applicants Review' },
            { id: 'wallet', icon: Wallet, label: 'Company Wallet' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                activeTab === item.id 
                  ? 'bg-white/10 text-white' 
                  : 'text-muted-foreground hover:text-white hover:bg-white/5'
              }`}
            >
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-white/5">
          <button 
            onClick={() => setIsSettingsOpen(true)}
            className="w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium text-muted-foreground hover:text-white hover:bg-white/5 transition-colors"
          >
            <Settings className="w-5 h-5" />
            <span>Settings</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative z-20 overflow-y-auto">
        <header className="h-16 border-b border-white/5 flex items-center justify-between px-8 bg-black/20 sticky top-0 backdrop-blur-sm z-30">
          <h1 className="text-xl font-bold text-white tracking-tight">Publisher Hub</h1>
          <NotificationCenter />
        </header>

        <div className="p-8 max-w-6xl mx-auto w-full">
          {activeTab === 'overview' && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="glass-panel p-6 rounded-2xl border border-white/5 relative overflow-hidden">
                  <p className="text-sm font-medium text-muted-foreground mb-4">Total Spent</p>
                  <h3 className="text-4xl font-bold text-white">₹8,500</h3>
                  <div className="absolute right-0 top-0 w-32 h-32 bg-intern-blue/10 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none" />
                </div>
                <div className="glass-panel p-6 rounded-2xl border border-white/5 relative overflow-hidden">
                  <p className="text-sm font-medium text-muted-foreground mb-4">Active Listings</p>
                  <h3 className="text-4xl font-bold text-white">14</h3>
                  <div className="absolute right-0 top-0 w-32 h-32 bg-purple-500/10 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none" />
                </div>
                <div className="glass-panel p-6 rounded-2xl border border-white/5 relative overflow-hidden">
                  <p className="text-sm font-medium text-muted-foreground mb-4">Pending Applications</p>
                  <h3 className="text-4xl font-bold text-white">{applications.length}</h3>
                  <div className="absolute right-0 top-0 w-32 h-32 bg-intern-blue/10 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none" />
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold text-white mb-6">Recent Applications</h3>
                <div className="glass-panel border-white/5 rounded-2xl overflow-hidden">
                  <table className="w-full text-sm text-left">
                    <thead className="bg-white/5 text-muted-foreground uppercase tracking-wider text-xs">
                      <tr>
                        <th className="px-6 py-4 font-medium">Applicant</th>
                        <th className="px-6 py-4 font-medium">Task</th>
                        <th className="px-6 py-4 font-medium">AI Score</th>
                        <th className="px-6 py-4 font-medium">Status</th>
                        <th className="px-6 py-4 font-medium text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {applications.map((app) => (
                        <tr key={app.id} className="hover:bg-white/5 transition-colors">
                          <td className="px-6 py-4 font-medium text-white">{app.intern.split('@')[0]}</td>
                          <td className="px-6 py-4 text-muted-foreground">{app.taskTitle || app.taskId}</td>
                          <td className="px-6 py-4">
                            <Badge variant="outline" className="border-intern-blue/30 text-intern-sky bg-intern-blue/10">{app.aiScore || '--'}/100</Badge>
                          </td>
                          <td className="px-6 py-4">
                            {getStatusBadge(app.status)}
                          </td>
                          <td className="px-6 py-4 text-right space-x-2">
                             <Button size="icon" variant="ghost" className="h-8 w-8 text-muted-foreground hover:text-white" onClick={() => app.proofUrl ? window.open(app.proofUrl, '_blank') : toast.info('No proof provided')}>
                               <Eye className="w-4 h-4" />
                             </Button>
                             {app.status === 'approved' && app.status !== 'paid' && (
                               <Button onClick={() => toast.success('Payment Initiated')} className="h-8 bg-intern-success text-white text-xs hover:bg-intern-success/90">Pay Bounty</Button>
                             )}
                          </td>
                        </tr>
                      ))}
                      {applications.length === 0 && (
                        <tr><td colSpan={5} className="px-6 py-8 text-center text-muted-foreground">No applications found.</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'wallet' && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-lg">
                <div className="glass-panel p-8 rounded-3xl relative overflow-hidden border border-white/10 shadow-2xl">
                  <div className="absolute inset-0 bg-gradient-to-br from-intern-blue/20 to-transparent pointer-events-none" />
                  <div className="relative z-10">
                    <p className="text-sm font-medium text-intern-sky mb-2 tracking-wide uppercase">Company Balance</p>
                    <h2 className="text-5xl font-bold text-white mb-6">₹12,450.00</h2>
                    <Button onClick={() => setIsFundingOpen(true)} className="bg-intern-blue text-white hover:bg-intern-blue/90 w-full font-semibold">Deposit Funds</Button>
                  </div>
                </div>
            </div>
          )}

          {activeTab === 'tasks' && (
             <div className="max-w-2xl animate-in fade-in slide-in-from-bottom-4 duration-500">
               <div className="glass-panel p-8 rounded-2xl border border-white/5 space-y-6">
                 <div>
                   <h2 className="text-2xl font-bold text-white mb-2">Create New Task</h2>
                   <p className="text-muted-foreground">Define the requirements, reward, and timeline.</p>
                 </div>
                 
                 <div className="space-y-4">
                   <div className="space-y-2">
                     <label className="text-sm font-medium text-white">Task Title</label>
                     <input type="text" value={newTask.title} onChange={e => setNewTask({...newTask, title: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white focus:outline-none focus:border-intern-blue" placeholder="e.g. Build a React landing page" />
                   </div>
                   <div className="space-y-2">
                     <label className="text-sm font-medium text-white">Reward Amount (₹)</label>
                     <input type="number" value={newTask.reward} onChange={e => setNewTask({...newTask, reward: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white focus:outline-none focus:border-intern-blue" placeholder="1000" />
                   </div>
                   <div className="space-y-2">
                     <label className="text-sm font-medium text-white">Detailed Description</label>
                     <textarea rows={4} value={newTask.description} onChange={e => setNewTask({...newTask, description: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white focus:outline-none focus:border-intern-blue resize-none" placeholder="Explain the exact deliverables..." />
                   </div>
                   <Button disabled={isPublishing} onClick={handlePublish} className="w-full bg-white text-intern-navy hover:bg-white/90 mt-4 rounded-xl font-bold">
                     {isPublishing ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                     {isPublishing ? 'Publishing...' : 'Publish Listing'}
                   </Button>
                 </div>
               </div>
             </div>
          )}
        </div>
      </main>
    </div>
  );
}
