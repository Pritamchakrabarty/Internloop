import { pgTable, serial, text, timestamp, integer } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  identifier: text("identifier").notNull().unique(),
  password: text("password"),
  role: text("role").default("user"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  reward: integer("reward").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull().default("open"),
  publisher: text("publisher").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const applications = pgTable("applications", {
  id: serial("id").primaryKey(),
  taskId: integer("task_id").references(() => tasks.id).notNull(),
  taskTitle: text("task_title").notNull(),
  intern: text("intern").notNull(),
  status: text("status").notNull().default("applied"),
  aiScore: integer("ai_score"),
  aiFeedback: text("ai_feedback"),
  proofUrl: text("proof_url"),
  notes: text("notes"),
  submittedAt: timestamp("submitted_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  message: text("message").notNull(),
  type: text("type").notNull(), // 'invitation', 'evaluation', etc.
  isRead: integer("is_read").default(0), // 0 for false, 1 for true
  createdAt: timestamp("created_at").defaultNow(),
});
