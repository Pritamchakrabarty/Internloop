import React, { useState } from 'react';
import { Toaster } from 'sonner';
import Landing from './pages/Landing';
import Dashboard from './pages/Dashboard';
import PublisherDashboard from './pages/PublisherDashboard';
import AdminDashboard from './pages/AdminDashboard';
import AdminLogin from './pages/AdminLogin';
import EvaluatorDashboard from './pages/EvaluatorDashboard';
import PrivacyPolicy from './pages/PrivacyPolicy';
import TermsAndConditions from './pages/TermsAndConditions';
import RefundPolicy from './pages/RefundPolicy';
import Chatbot from './components/Chatbot';
import Footer from './components/Footer';
import AuthModal from './components/AuthModal';
import OnboardingModal from './components/OnboardingModal';

import Manifesto from './pages/Manifesto';
import HowItWorks from './pages/HowItWorks';

type PageType = 'landing' | 'dashboard' | 'publisher' | 'admin' | 'admin-login' | 'evaluator' | 'privacy' | 'terms' | 'refund' | 'manifesto' | 'how-it-works';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageType>('landing');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [isOnboardingModalOpen, setIsOnboardingModalOpen] = useState(false);

  // Go back to previous main page. For simplicity, we just go back to landing if on a policy page.
  const handleBack = () => {
    setCurrentPage('landing');
  };

  const handleLoginSuccess = () => {
    setIsAuthModalOpen(false);
    const savedRole = localStorage.getItem('user_role');
    if (savedRole === 'intern') {
      setCurrentPage('dashboard');
    } else if (savedRole === 'evaluator') {
      setCurrentPage('evaluator');
    } else if (savedRole === 'publisher') {
      setCurrentPage('publisher');
    } else {
      setIsOnboardingModalOpen(true);
    }
  };

  const handleOnboardingSuccess = async (role: 'intern' | 'evaluator' | 'publisher') => {
    try {
      const res = await fetch('/api/users/role', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        },
        body: JSON.stringify({ role })
      });
      const data = await res.json();
      
      // We set the resolved role (could be 'pending_publisher')
      if (data.role) {
         localStorage.setItem('user_role', data.role);
      } else {
         localStorage.setItem('user_role', role);
      }
    } catch (e) {
      console.error("Failed to update role", e);
      localStorage.setItem('user_role', role); // Fallback
    }
    
    setIsOnboardingModalOpen(false);
    
    const updatedRole = localStorage.getItem('user_role');
    if (updatedRole === 'intern') setCurrentPage('dashboard');
    if (updatedRole === 'evaluator') setCurrentPage('evaluator');
    if (updatedRole === 'publisher') setCurrentPage('publisher');
    if (updatedRole === 'pending_publisher') setCurrentPage('landing'); // Give them a notification or stay on landing
  };

  const openLogin = () => {
    setAuthMode('login');
    setIsAuthModalOpen(true);
  };

  const openSignup = () => {
    setAuthMode('signup');
    setIsAuthModalOpen(true);
  };

  return (
    <div className="flex min-h-screen w-full flex-col font-sans relative">
      <Toaster theme="dark" position="bottom-right" />
      <div className="flex-1">
        {currentPage === 'landing' && (
          <Landing 
            onLogin={openLogin} 
            onSignup={openSignup}
            onStart={() => setCurrentPage('dashboard')} 
            onGoToPublisher={() => setCurrentPage('publisher')}
            onGoToAdmin={() => setCurrentPage('admin-login')}
            onGoToEvaluator={() => setCurrentPage('evaluator')}
            onGoToManifesto={() => setCurrentPage('manifesto')}
            onGoToHowItWorks={() => setCurrentPage('how-it-works')}
          />
        )}
        {currentPage === 'dashboard' && <Dashboard onNavigate={() => setCurrentPage('landing')} />}
        {currentPage === 'publisher' && <PublisherDashboard onNavigate={() => setCurrentPage('landing')} />}
        {currentPage === 'admin-login' && <AdminLogin onBack={() => setCurrentPage('landing')} onSuccess={() => setCurrentPage('admin')} />}
        {currentPage === 'admin' && <AdminDashboard onNavigate={() => setCurrentPage('landing')} />}
        {currentPage === 'evaluator' && <EvaluatorDashboard onNavigate={() => setCurrentPage('landing')} />}
        {currentPage === 'privacy' && <PrivacyPolicy onBack={handleBack} />}
        {currentPage === 'terms' && <TermsAndConditions onBack={handleBack} />}
        {currentPage === 'refund' && <RefundPolicy onBack={handleBack} />}
        {currentPage === 'manifesto' && <Manifesto onBack={handleBack} onStart={() => setCurrentPage('dashboard')} />}
        {currentPage === 'how-it-works' && <HowItWorks onBack={handleBack} onStart={() => setCurrentPage('dashboard')} />}
      </div>
      
      <Footer onNavigate={(page) => setCurrentPage(page as PageType)} />
      <Chatbot />
      
      <AuthModal 
        isOpen={isAuthModalOpen} 
        onClose={() => setIsAuthModalOpen(false)} 
        onSuccess={handleLoginSuccess}
        initialStep={authMode}
      />

      <OnboardingModal 
        isOpen={isOnboardingModalOpen}
        onClose={() => setIsOnboardingModalOpen(false)}
        onSuccess={handleOnboardingSuccess}
      />
    </div>
  );
}

