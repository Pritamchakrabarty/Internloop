import React, { useState } from 'react';
import { X, User, CheckCircle2, Bot, Loader2, Award, Briefcase, UploadCloud, ScanFace, ShieldCheck, Fingerprint } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

interface OnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (role: 'intern' | 'evaluator' | 'publisher') => void;
}

const INTERN_QUESTIONS = [
  { q: "What is the primary purpose of the 'useEffect' hook in React?", options: ["To structure the HTML layout.", "To perform side effects in functional components.", "To style the components.", "To handle routing between pages."], answer: 1 },
  { q: "In JavaScript, what is the output of `typeof null`?", options: ["'object'", "'null'", "'undefined'", "'boolean'"], answer: 0 },
  { q: "What is the correct way to update state in React?", options: ["state.value = 1", "this.state.value = 1", "setState() or updater function", "updateState()"], answer: 2 },
  { q: "What does CSS stand for?", options: ["Computer Style Sheets", "Cascading Style Sheets", "Creative Style Sheets", "Colorful Style Sheets"], answer: 1 },
  { q: "How do you pass data from a parent to a child component in React?", options: ["Using Context", "Using State", "Using Props", "Using Redux"], answer: 2 },
  { q: "Which HTTP method is typically used to create a new resource?", options: ["GET", "POST", "PUT", "DELETE"], answer: 1 },
  { q: "What does the 'key' prop do in React lists?", options: ["Sets the id of the element", "Helps React identify which items have changed", "Applies a unique CSS class", "Encrypts the element"], answer: 1 },
  { q: "What does 'DRY' stand for in programming?", options: ["Don't Repeat Yourself", "Do React Yourself", "Delete Redundant YAML", "Dual Render Yield"], answer: 0 },
  { q: "Which tool is commonly used to bundle modern JavaScript apps?", options: ["NPM", "Webpack", "Babel", "ESLint"], answer: 1 },
  { q: "What does a Promise represent in JavaScript?", options: ["A guaranteed return value", "An operation that hasn't completed yet", "A syntax error handler", "A network request"], answer: 1 }
];

const EVALUATOR_QUESTIONS = [
  { q: "When reviewing a pull request, what is the most critical aspect to look for?", options: ["If the code looks neat.", "Logic correctness, security, and requirement fulfillment.", "If the developer used tabs or spaces.", "If the PR description is long enough."], answer: 1 },
  { q: "What is a 'code smell'?", options: ["Code that throws syntax errors", "A surface indication that usually corresponds to a deeper problem", "A successful compilation message", "A deprecated library"], answer: 1 },
  { q: "Why is having good test coverage important?", options: ["It guarantees there are no bugs", "It catches regressions and verifies behavior", "It makes the code run faster", "It replaces the need for QA"], answer: 1 },
  { q: "What is the main advantage of TypeScript over JavaScript?", options: ["It executes faster in the browser", "It provides static typing and catches errors at compile time", "It has more built-in functions", "It doesn't require compilation"], answer: 1 },
  { q: "When should you reject a pull request?", options: ["When you don't like the author", "When it introduces bugs, breaks CI, or doesn't meet requirements", "When it has more than 100 lines of code", "When it uses `let` instead of `const`"], answer: 1 },
  { q: "What does continuous integration (CI) involve?", options: ["Writing code continuously without breaks", "Automatically building and testing code changes", "Deploying to production on every commit", "Manually reviewing all code changes"], answer: 1 },
  { q: "What should you do if an PR is too large to review effectively?", options: ["Approve it and test later", "Reject it without comments", "Ask the author to split it into smaller, focused PRs", "Skim it and approve"], answer: 2 },
  { q: "What is a memory leak?", options: ["When code accidentally logs secrets", "When a program incorrectly manages memory allocations", "When the database size exceeds limits", "When an API rate limit is hit"], answer: 1 },
  { q: "Why is semantic versioning (SemVer) useful?", options: ["It makes version numbers look professional", "It communicates the nature of changes (major/minor/patch)", "It enforces backward compatibility automatically", "It prevents dependency hell completely"], answer: 1 },
  { q: "What are SOLID principles?", options: ["A set of guidelines for UI design", "Five design principles intended to make software designs more understandable, flexible, and maintainable", "A database optimization technique", "A framework for agile development"], answer: 1 }
];

export default function OnboardingModal({ isOpen, onClose, onSuccess }: OnboardingModalProps) {
  const [step, setStep] = useState<'role' | 'security' | 'exam' | 'result' | 'publisher-kyc' | 'publisher-pending'>('role');
  const [selectedRole, setSelectedRole] = useState<'intern' | 'evaluator' | 'publisher' | null>(null);
  
  // Security state
  const [securityProgress, setSecurityProgress] = useState(0);
  
  // Simple Mock Exam State
  const [examQuestions, setExamQuestions] = useState<any[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [hasPassed, setHasPassed] = useState<boolean | null>(null);

  // Publisher details
  const [pubDetails, setPubDetails] = useState({ companyName: '', idUploaded: false });

  // Restart modal state when opened
  React.useEffect(() => {
    if (isOpen) {
      setStep('role');
      setSelectedRole(null);
      setSelectedAnswer(null);
      setIsEvaluating(false);
      setHasPassed(null);
      setPubDetails({ companyName: '', idUploaded: false });
      setCurrentQuestionIndex(0);
      setScore(0);
      setExamQuestions([]);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleRoleSelect = (role: 'intern' | 'evaluator' | 'publisher') => {
    setSelectedRole(role);
    setSecurityProgress(0);
    setStep('security');
    
    // Simulate high-level biometric scan
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.random() * 15;
      if (progress >= 100) {
        progress = 100;
        clearInterval(interval);
        setTimeout(() => {
          if (role === 'publisher') {
            setStep('publisher-kyc');
          } else {
            const pool = role === 'intern' ? INTERN_QUESTIONS : EVALUATOR_QUESTIONS;
            const shuffled = [...pool].sort(() => 0.5 - Math.random());
            setExamQuestions(shuffled.slice(0, 5));
            setStep('exam');
          }
        }, 1000);
      }
      setSecurityProgress(progress);
    }, 300);
  };

  const handleSubmitExam = () => {
    if (selectedAnswer === null) {
      toast.error('Please select an answer');
      return;
    }

    const currentQuestion = examQuestions[currentQuestionIndex];
    if (selectedAnswer === currentQuestion.answer) {
      setScore(prev => prev + 1);
    }

    if (currentQuestionIndex < 4) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedAnswer(null);
    } else {
      setIsEvaluating(true);
      // Simulate AI grading
      setTimeout(() => {
        setIsEvaluating(false);
        const finalScore = score + (selectedAnswer === currentQuestion.answer ? 1 : 0);
        const passed = finalScore >= 3; // Passed if 3 or more out of 5
        setHasPassed(passed);
        setStep('result');
      }, 2000);
    }
  };

  const handlePublisherSubmit = () => {
    if (!pubDetails.companyName.trim()) {
      toast.error('Company Name is required');
      return;
    }
    if (!pubDetails.idUploaded) {
      toast.error('Please upload an ID/Registration document');
      return;
    }
    setIsEvaluating(true);
    setTimeout(() => {
      setIsEvaluating(false);
      setStep('publisher-pending');
    }, 2000);
  };

  const handleFinish = () => {
    if (selectedRole === 'publisher') {
      onSuccess('publisher');
    } else if (hasPassed && selectedRole) {
      onSuccess(selectedRole as 'intern' | 'evaluator');
    } else {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#0f172a] border border-white/10 rounded-2xl w-full max-w-2xl overflow-hidden relative shadow-2xl min-h-[400px] flex flex-col my-8">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-intern-blue to-purple-500" />
        
        <div className="p-6 border-b border-white/10 flex justify-between items-center bg-black/20">
          <h2 className="text-xl font-bold text-white">Platform Onboarding</h2>
          {step === 'role' && (
            <button onClick={onClose} className="text-muted-foreground hover:text-white transition-colors">
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        <div className="p-8 flex-1 flex flex-col justify-center">
          {step === 'role' && (
            <div className="animate-in fade-in zoom-in-95 duration-300">
              <h3 className="text-2xl font-bold text-white mb-2 text-center">Choose your path</h3>
              <p className="text-muted-foreground text-center mb-8">Tell us what you want to achieve on InternLoop.</p>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <button 
                  onClick={() => handleRoleSelect('intern')}
                  className="flex flex-col items-center p-6 border border-white/10 rounded-xl bg-white/5 hover:bg-intern-blue/10 hover:border-intern-blue/50 transition-all text-center group"
                >
                  <div className="w-16 h-16 rounded-full bg-intern-blue/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <User className="w-8 h-8 text-intern-sky" />
                  </div>
                  <h4 className="text-lg font-bold text-white mb-2">Intern</h4>
                  <p className="text-sm text-muted-foreground">I want to apply for tasks, build my portfolio, and earn money.</p>
                </button>

                <button 
                  onClick={() => handleRoleSelect('evaluator')}
                  className="flex flex-col items-center p-6 border border-white/10 rounded-xl bg-white/5 hover:bg-purple-500/10 hover:border-purple-500/50 transition-all text-center group"
                >
                  <div className="w-16 h-16 rounded-full bg-purple-500/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <CheckCircle2 className="w-8 h-8 text-purple-400" />
                  </div>
                  <h4 className="text-lg font-bold text-white mb-2">Evaluator</h4>
                  <p className="text-sm text-muted-foreground">I want to review code submissions alongside the AI engine.</p>
                </button>
                
                <button 
                  onClick={() => handleRoleSelect('publisher')}
                  className="flex flex-col items-center p-6 border border-white/10 rounded-xl bg-white/5 hover:bg-intern-success/10 hover:border-intern-success/50 transition-all text-center group"
                >
                  <div className="w-16 h-16 rounded-full bg-intern-success/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <Briefcase className="w-8 h-8 text-intern-success" />
                  </div>
                  <h4 className="text-lg font-bold text-white mb-2">Publisher</h4>
                  <p className="text-sm text-muted-foreground">I want to post tasks and pay interns for high-quality work.</p>
                </button>
              </div>
            </div>
          )}

          {step === 'security' && (
            <div className="flex flex-col items-center justify-center text-center animate-in zoom-in-95 duration-500 py-8">
              <div className="relative mb-8">
                <div className="w-32 h-32 rounded-full border-2 border-dashed border-white/20 flex items-center justify-center relative overflow-hidden">
                   <ScanFace className={`w-16 h-16 ${securityProgress >= 100 ? 'text-intern-success' : 'text-intern-sky'} transition-colors duration-500`} />
                   
                   {/* Scanning animation bar */}
                   {securityProgress < 100 && (
                     <div className="absolute left-0 right-0 h-0.5 bg-intern-blue shadow-[0_0_15px_rgba(37,99,235,0.8)] animate-scan" />
                   )}
                </div>
                
                {/* Orbital dots */}
                <div className={`absolute -inset-4 border border-white/10 rounded-full animate-[spin_4s_linear_infinite] ${securityProgress >= 100 ? 'border-intern-success/30' : ''}`}>
                  <div className={`w-3 h-3 absolute top-0 left-1/2 -ml-1.5 -mt-1.5 rounded-full ${securityProgress >= 100 ? 'bg-intern-success shadow-[0_0_10px_rgba(16,185,129,0.8)]' : 'bg-intern-sky shadow-[0_0_10px_rgba(56,189,248,0.8)]'}`} />
                </div>
              </div>
              
              <h3 className="text-2xl font-bold text-white mb-2">
                {securityProgress >= 100 ? 'Identity Verified' : 'World-Class Security Check'}
              </h3>
              
              <p className="text-muted-foreground mb-6 h-12 flex items-center justify-center">
                {securityProgress >= 100 
                  ? 'Advanced biometric and behavioral patterns analyzed. Access granted.' 
                  : 'Initializing behavioral biometrics and establishing secure encrypted tunnel...'}
              </p>
              
              <div className="w-full max-w-xs mx-auto">
                <div className="flex justify-between text-xs text-muted-foreground mb-1 font-mono">
                  <span>ENCRYPTION_LEVEL: MIL-STD</span>
                  <span>{Math.min(100, Math.round(securityProgress))}%</span>
                </div>
                <div className="h-1 bg-white/10 rounded overflow-hidden">
                  <div 
                    className={`h-full ${securityProgress >= 100 ? 'bg-intern-success' : 'bg-intern-blue'} transition-all duration-300 ease-out`}
                    style={{ width: `${Math.min(100, securityProgress)}%` }}
                  />
                </div>
                {securityProgress >= 100 && (
                  <div className="flex items-center justify-center gap-2 mt-4 text-xs font-bold text-intern-success animate-in fade-in duration-500">
                    <ShieldCheck className="w-4 h-4" /> SECURE TUNNEL ESTABLISHED
                  </div>
                )}
              </div>
            </div>
          )}

          {step === 'exam' && examQuestions.length > 0 && (
            <div className="animate-in slide-in-from-right-8 duration-300">
              <div className="flex items-center gap-3 mb-6">
                 <div className="p-2 bg-intern-blue/20 rounded-lg">
                   <Bot className="w-6 h-6 text-intern-sky" />
                 </div>
                 <div>
                   <h3 className="text-xl font-bold text-white">Qualification Exam</h3>
                   <p className="text-sm text-muted-foreground">Question {currentQuestionIndex + 1} of 5</p>
                 </div>
              </div>

              <div className="space-y-6">
                <div className="p-4 bg-black/30 border border-white/5 rounded-xl">
                  <p className="text-white font-medium mb-4">
                    {examQuestions[currentQuestionIndex].q}
                  </p>
                  
                  <div className="space-y-3">
                    {examQuestions[currentQuestionIndex].options.map((option: string, idx: number) => (
                      <button
                        key={idx}
                        onClick={() => setSelectedAnswer(idx)}
                        className={`w-full text-left p-4 rounded-xl border transition-all ${
                          selectedAnswer === idx 
                            ? 'bg-intern-blue/20 border-intern-blue text-white' 
                            : 'bg-white/5 border-white/10 text-muted-foreground hover:bg-white/10 hover:text-white'
                        }`}
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                </div>

                <Button 
                  onClick={handleSubmitExam} 
                  disabled={isEvaluating || selectedAnswer === null}
                  className="w-full bg-intern-blue text-white hover:bg-intern-blue/90"
                >
                  {isEvaluating ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      Evaluating via AI...
                    </>
                  ) : (currentQuestionIndex < 4 ? 'Next Question' : 'Submit Exam')}
                </Button>
              </div>
            </div>
          )}

          {step === 'publisher-kyc' && (
            <div className="animate-in slide-in-from-right-8 duration-300">
              <div className="mb-6">
                <h3 className="text-2xl font-bold text-white">Publisher Verification</h3>
                <p className="text-sm text-muted-foreground">Please provide your company details to get verified.</p>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-white">Company or Individual Name</label>
                  <input
                    type="text"
                    value={pubDetails.companyName}
                    onChange={(e) => setPubDetails({ ...pubDetails, companyName: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-intern-blue"
                    placeholder="e.g. Acme Corp"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-white">ID Card / Company Registration Document</label>
                  <div 
                    className={`border-2 border-dashed ${pubDetails.idUploaded ? 'border-intern-success bg-intern-success/10' : 'border-white/20 bg-white/5'} rounded-xl p-8 flex flex-col items-center justify-center cursor-pointer transition-colors hover:bg-white/10`}
                    onClick={() => {
                      setPubDetails({ ...pubDetails, idUploaded: true });
                      toast.success('Document uploaded successfully for review.');
                    }}
                  >
                    {pubDetails.idUploaded ? (
                      <>
                        <CheckCircle2 className="w-10 h-10 text-intern-success mb-2" />
                        <p className="text-white font-medium">Document Uploaded</p>
                        <p className="text-xs text-muted-foreground mt-1">Click to replace</p>
                      </>
                    ) : (
                      <>
                        <UploadCloud className="w-10 h-10 text-muted-foreground mb-2" />
                        <p className="text-white font-medium">Click to upload document</p>
                        <p className="text-xs text-muted-foreground mt-1">Supports PDF, JPG, PNG up to 10MB</p>
                      </>
                    )}
                  </div>
                </div>

                <Button 
                  onClick={handlePublisherSubmit} 
                  disabled={isEvaluating}
                  className="w-full bg-intern-blue text-white hover:bg-intern-blue/90 mt-4 h-12 text-lg"
                >
                  {isEvaluating ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin mr-2" />
                      Submitting for Verification...
                    </>
                  ) : 'Submit for Verification'}
                </Button>
              </div>
            </div>
          )}

          {step === 'publisher-pending' && (
            <div className="flex flex-col items-center justify-center text-center animate-in zoom-in-95 duration-500 py-8">
              <div className="w-20 h-20 bg-yellow-500/20 rounded-full flex items-center justify-center mb-6">
                <Loader2 className="w-10 h-10 text-yellow-500 animate-spin" />
              </div>
              <h3 className="text-3xl font-bold text-white mb-2">Under Review</h3>
              <p className="text-muted-foreground mb-8 text-lg">
                Your details have been submitted to the admin team for verification. 
                They will review your documents shortly.
              </p>
              <Button onClick={handleFinish} variant="outline" className="border-white/20 text-white px-8 py-6 rounded-full font-bold text-lg w-full max-w-sm">
                Enter Publisher Dashboard (Simulation)
              </Button>
            </div>
          )}

          {step === 'result' && (
            <div className="flex flex-col items-center justify-center text-center animate-in zoom-in-95 duration-500 py-8">
              {hasPassed ? (
                <>
                  <div className="w-20 h-20 bg-intern-success/20 rounded-full flex items-center justify-center mb-6 shadow-[0_0_50px_rgba(34,197,94,0.3)]">
                    <Award className="w-10 h-10 text-intern-success" />
                  </div>
                  <h3 className="text-3xl font-bold text-white mb-2">Congratulations!</h3>
                  <p className="text-muted-foreground mb-8 text-lg">
                    You've passed the qualification exam. You are now officially verified as a {selectedRole} on InternLoop.
                  </p>
                  <Button onClick={handleFinish} className="bg-intern-success hover:bg-intern-success/90 text-white px-8 py-6 rounded-full font-bold text-lg w-full max-w-sm">
                    Enter Dashboard
                  </Button>
                </>
              ) : (
                <>
                  <div className="w-20 h-20 bg-red-500/20 rounded-full flex items-center justify-center mb-6">
                    <X className="w-10 h-10 text-red-500" />
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-2">Not quite there.</h3>
                  <p className="text-muted-foreground mb-8">
                    Unfortunately, you did not pass the qualification exam. Review the materials and try again later.
                  </p>
                  <Button variant="outline" onClick={handleFinish} className="border-white/20 text-white w-full max-w-xs">
                    Close
                  </Button>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

