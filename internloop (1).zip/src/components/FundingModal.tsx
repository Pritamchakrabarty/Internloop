import React, { useState, useCallback } from 'react';
import { useRazorpay } from 'react-razorpay';
import { X, CreditCard, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function FundingModal({ isOpen, onClose }: { isOpen: boolean, onClose: () => void }) {
  const [amount, setAmount] = useState(5000); // Default ₹5000
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const { error: rzpError, isLoading, Razorpay } = useRazorpay();

  // When modal closes, reset states
  React.useEffect(() => {
    if (!isOpen) {
      setSuccess(false);
      setError('');
      setIsProcessing(false);
    }
  }, [isOpen]);

  const handlePayment = useCallback(async () => {
    if (!Razorpay) {
       setError('Payment gateway is still loading. Please try again.');
       return;
    }
    setIsProcessing(true);
    setError('');
    
    try {
      // 1. Create order on server
      const res = await fetch('/api/create-order', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        },
        body: JSON.stringify({ amount: amount * 100 })
      });
      const data = await res.json();
      
      if (!res.ok) throw new Error(data.error);
      
      // 2. Open Razorpay Checkout
      const options = {
        key: (import.meta as any).env.VITE_RAZORPAY_KEY_ID || 'rzp_test_placeholder', // Enter the Key ID generated from the Dashboard
        amount: data.amount, // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
        currency: data.currency,
        name: "InternLoop",
        description: "Wallet Funding",
        order_id: data.orderId, //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
        handler: function (response: any) {
             // We can optionally verify the signature here
             // console.log(response.razorpay_payment_id, response.razorpay_order_id, response.razorpay_signature)
             setSuccess(true);
        },
        prefill: {
            name: "Developer Intern",
            email: "dev@example.com",
            contact: "9999999999"
        },
        theme: {
            color: "#2563EB"
        }
      };

      const rzp1 = new Razorpay(options);
      
      rzp1.on('payment.failed', function (response: any){
              setError(response.error.description || 'Payment Failed');
      });

      rzp1.open();
    } catch (err: any) {
      setError(err.message || 'Failed to initialize payment.');
    } finally {
      setIsProcessing(false);
    }
  }, [Razorpay, amount]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-[#0B1426] border border-white/10 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden relative">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-muted-foreground hover:text-white p-1 rounded-md hover:bg-white/10 transition-colors z-10"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-6">
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-white mb-2 flex items-center gap-2">
              <CreditCard className="w-6 h-6 text-intern-sky" /> 
              Fund Wallet
            </h2>
            <p className="text-muted-foreground text-sm">Add funds securely to your escrow wallet.</p>
          </div>

          {success ? (
            <div className="text-center py-6">
              <div className="w-16 h-16 bg-intern-success/20 rounded-full flex items-center justify-center mx-auto mb-4 border border-intern-success/30">
                <CreditCard className="w-8 h-8 text-intern-success" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Payment Successful!</h3>
              <p className="text-muted-foreground mb-6">₹{amount} has been added to your balance.</p>
              <Button onClick={onClose} className="w-full bg-intern-blue hover:bg-intern-blue/90 text-white">Done</Button>
            </div>
          ) : (
            <div className="space-y-6">
              <div>
                <label className="text-sm font-medium text-white mb-2 block">Amount (INR)</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-white font-medium">₹</span>
                  <input 
                    type="number" 
                    value={amount}
                    onChange={(e) => setAmount(Number(e.target.value))}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-8 pr-4 text-white focus:outline-none focus:border-intern-blue focus:ring-1 focus:ring-intern-blue transition-all"
                  />
                </div>
              </div>
              
              {error && <div className="text-red-400 text-sm font-medium p-3 bg-red-400/10 rounded-lg border border-red-400/20">{error}</div>}

              <Button 
                onClick={handlePayment} 
                className="w-full bg-intern-blue hover:bg-intern-blue/90 text-white h-12"
                disabled={isProcessing || isLoading || amount < 100}
              >
                {isProcessing || isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : `Pay ₹${amount}`}
              </Button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
