import React, { useState } from 'react';
import { X, Building2, Smartphone, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

export default function WithdrawModal({ isOpen, onClose }: { isOpen: boolean, onClose: () => void }) {
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState<'bank' | 'upi'>('bank');
  const [destination, setDestination] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  const handleWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || Number(amount) <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }
    if (!destination) {
      toast.error(`Please enter your ${method === 'bank' ? 'Account Number' : 'UPI ID'}`);
      return;
    }

    setIsProcessing(true);
    try {
      const res = await fetch('/api/withdraw', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        },
        body: JSON.stringify({ amount: Number(amount), method, destination })
      });
      const data = await res.json();
      
      if (!res.ok) throw new Error(data.error);

      toast.success(data.message, {
        description: `₹${amount} withdrawal initiated via ${method === 'upi' ? 'UPI' : 'Bank Transfer'}.`
      });
      
      setTimeout(() => {
        onClose();
        setAmount('');
        setDestination('');
      }, 500);

    } catch (err: any) {
      toast.error(err.message || 'Failed to process withdrawal');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#0f172a] border border-white/10 rounded-2xl w-full max-w-md overflow-hidden relative shadow-2xl">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-intern-blue to-intern-sky" />
        
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold text-white">Withdraw Funds</h2>
            <button onClick={onClose} className="text-muted-foreground hover:text-white transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleWithdraw} className="space-y-6">
            <div className="space-y-3">
              <label className="text-sm font-medium text-white block">Select Payout Method</label>
              <div className="grid grid-cols-2 gap-3">
                <div 
                  onClick={() => setMethod('bank')}
                  className={`border rounded-xl p-4 flex flex-col items-center gap-2 cursor-pointer transition-all ${method === 'bank' ? 'border-intern-blue bg-intern-blue/10 text-intern-sky' : 'border-white/10 text-muted-foreground hover:border-white/20'}`}
                >
                  <Building2 className="w-6 h-6" />
                  <span className="text-sm font-medium">Bank Transfer</span>
                </div>
                <div 
                  onClick={() => setMethod('upi')}
                  className={`border rounded-xl p-4 flex flex-col items-center gap-2 cursor-pointer transition-all ${method === 'upi' ? 'border-intern-blue bg-intern-blue/10 text-intern-sky' : 'border-white/10 text-muted-foreground hover:border-white/20'}`}
                >
                  <Smartphone className="w-6 h-6" />
                  <span className="text-sm font-medium">UPI</span>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-white">Amount (₹)</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground font-medium">₹</span>
                <input 
                  type="number" 
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-10 py-3 text-white focus:outline-none focus:border-intern-blue focus:ring-1 focus:ring-intern-blue transition-all"
                  min="1"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-white">{method === 'bank' ? 'Account Number' : 'UPI ID'}</label>
              <input 
                type="text" 
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                placeholder={method === 'bank' ? "Enter account number" : "example@upi"}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-intern-blue focus:ring-1 focus:ring-intern-blue transition-all"
              />
            </div>

            <Button 
              type="submit" 
              disabled={isProcessing} 
              className="w-full bg-intern-blue text-white hover:bg-intern-blue/90 py-6 font-semibold"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Processing...
                </>
              ) : (
                `Withdraw ${amount ? `₹${amount}` : "Funds"}`
              )}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
