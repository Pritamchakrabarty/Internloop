import React, { useState } from 'react';
import { X, Link as LinkIcon, Upload, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface SubmitWorkModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (proofUrl: string, notes: string) => Promise<void>;
  taskTitle: string;
}

export default function SubmitWorkModal({ isOpen, onClose, onSubmit, taskTitle }: SubmitWorkModalProps) {
  const [proofUrl, setProofUrl] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!proofUrl) return;

    setIsSubmitting(true);
    try {
      await onSubmit(proofUrl, notes);
      setProofUrl('');
      setNotes('');
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm">
      <div className="bg-secondary/50 border border-border rounded-2xl w-full max-w-md overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-200">
        <div className="flex justify-between items-center p-6 border-b border-border">
          <h3 className="font-semibold text-foreground">Submit Work for Review</h3>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <p className="text-sm text-muted-foreground mb-4">
              Task: <span className="text-foreground font-medium">{taskTitle}</span>
            </p>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground/80">Proof of Work URL</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <LinkIcon className="h-4 w-4 text-muted-foreground" />
              </div>
              <input
                type="url"
                value={proofUrl}
                onChange={(e) => setProofUrl(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-background border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-intern-blue/50"
                placeholder="https://github.com/your/repo"
                required
              />
            </div>
            <p className="text-xs text-muted-foreground mt-1">Provide a link to your PR, code repository, or live deployment.</p>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground/80">Additional Notes (Optional)</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full p-3 bg-background border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-intern-blue/50 resize-none h-24"
              placeholder="Any details the evaluator should know..."
            />
          </div>

          <div className="pt-4 flex justify-end gap-3">
            <Button type="button" variant="ghost" onClick={onClose}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-intern-blue text-white hover:bg-intern-blue/90"
              disabled={isSubmitting || !proofUrl}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4 mr-2" />
                  Submit Work
                </>
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
