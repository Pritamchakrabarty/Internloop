import React, { useEffect, useState } from 'react';
import { X, ArrowDownRight, ArrowUpRight, Loader2, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

interface Transaction {
  id: string;
  type: 'deposit' | 'withdrawal';
  amount: number;
  status: 'success' | 'processing' | 'failed';
  date: string;
  method: string;
}

export default function TransactionsModal({ isOpen, onClose }: { isOpen: boolean, onClose: () => void }) {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (isOpen) {
      setIsLoading(true);
      fetch('/api/transactions', { headers: { 'Authorization': `Bearer ${localStorage.getItem('auth_token')}` } })
        .then(res => res.json())
        .then(data => {
          setTransactions(data.transactions || []);
        })
        .catch(err => {
          console.error(err);
          toast.error("Failed to load transactions");
        })
        .finally(() => {
          setIsLoading(false);
        });
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#0f172a] border border-white/10 rounded-2xl w-full max-w-2xl overflow-hidden relative shadow-2xl flex flex-col max-h-[85vh]">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-intern-blue to-intern-sky" />
        
        <div className="p-6 border-b border-white/10 flex justify-between items-center shrink-0">
          <div>
            <h2 className="text-xl font-bold text-white">Transaction History</h2>
            <p className="text-sm text-muted-foreground mt-1">Your recent wallet activity and payouts</p>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="outline" className="border-white/10 text-white h-9" onClick={() => toast.success("Statement downloaded")}>
              <Download className="w-4 h-4 mr-2" />
              Statement
            </Button>
            <button onClick={onClose} className="text-muted-foreground hover:text-white transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-6 overflow-y-auto min-h-[300px]">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
              <Loader2 className="w-8 h-8 animate-spin mb-4 text-intern-blue" />
              <p>Loading transactions...</p>
            </div>
          ) : transactions.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
              <p>No transactions found.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {transactions.map((txn) => (
                <div key={txn.id} className="p-4 bg-white/5 border border-white/5 rounded-xl flex items-center justify-between hover:bg-white/10 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${txn.type === 'deposit' ? 'bg-intern-success/20 text-intern-success' : 'bg-red-500/20 text-red-500'}`}>
                      {txn.type === 'deposit' ? <ArrowDownRight className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
                    </div>
                    <div>
                      <p className="font-medium text-white">{txn.type === 'deposit' ? 'Wallet Top-up' : 'Withdrawal to Bank/UPI'}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs text-muted-foreground">{new Date(txn.date).toLocaleDateString()} &middot; {new Date(txn.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                        <span className="text-xs text-muted-foreground">&middot;</span>
                        <span className="text-xs text-muted-foreground">{txn.method}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`font-bold ${txn.type === 'deposit' ? 'text-intern-success' : 'text-white'}`}>
                      {txn.type === 'deposit' ? '+' : '-'}₹{txn.amount.toLocaleString()}
                    </p>
                    <Badge variant="outline" className={`mt-1 text-[10px] ${
                      txn.status === 'success' ? 'border-intern-success/30 text-intern-success bg-intern-success/10' : 
                      txn.status === 'processing' ? 'border-yellow-500/30 text-yellow-500 bg-yellow-500/10' : 
                      'border-red-500/30 text-red-500 bg-red-500/10'
                    }`}>
                      {txn.status.charAt(0).toUpperCase() + txn.status.slice(1)}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
