import React, { useState } from 'react';
import { X, User, Bell, Shield, Paintbrush, Loader2, LogOut, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogout?: () => void;
}

import { useTheme } from './ThemeProvider';

function ThemeSettingsTab() {
  const { theme, setTheme } = useTheme();

  return (
    <div className="space-y-6">
      <div>
        <h4 className="text-white font-medium mb-3">Theme Preference</h4>
        <div className="grid grid-cols-2 gap-4 max-w-md">
          <div 
            onClick={() => setTheme('dark')}
            className={`border rounded-xl p-4 flex flex-col items-center gap-2 cursor-pointer transition-all ${theme === 'dark' ? 'border-intern-blue bg-intern-blue/5' : 'border-white/10 bg-white/5 opacity-50 hover:opacity-100'}`}
          >
            <div className="w-full h-20 rounded bg-[#0f172a] border border-white/10" />
            <span className="text-sm text-white font-medium">Dark Mode</span>
          </div>
          <div 
            onClick={() => setTheme('light')}
            className={`border rounded-xl p-4 flex flex-col items-center gap-2 cursor-pointer transition-all ${theme === 'light' ? 'border-intern-blue bg-white/10 text-black' : 'border-white/10 bg-white/5 opacity-50 hover:opacity-100'}`}
          >
            <div className="w-full h-20 rounded bg-white border border-gray-200" />
            <span className="text-sm text-white font-medium">Light Mode</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function SettingsModal({ isOpen, onClose, onLogout }: SettingsModalProps) {
  const [activeTab, setActiveTab] = useState('profile');
  const [isSaving, setIsSaving] = useState(false);

  if (!isOpen) return null;

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => {
      setIsSaving(false);
      toast.success('Settings saved successfully');
    }, 1000);
  };

  const handleLogout = () => {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('user_role');
    onClose();
    if (onLogout) {
      onLogout();
    } else {
      window.location.reload();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#0f172a] border border-white/10 rounded-2xl w-full max-w-4xl overflow-hidden relative shadow-2xl flex h-[600px]">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-intern-blue to-intern-sky" />
        
        {/* Sidebar */}
        <div className="w-64 border-r border-white/10 bg-black/20 p-6 flex flex-col pt-8">
          <h2 className="text-xl font-bold text-white mb-6">Settings</h2>
          
          <nav className="space-y-1 flex-1">
            {[
              { id: 'profile', icon: User, label: 'Profile Settings' },
              { id: 'notifications', icon: Bell, label: 'Notifications' },
              { id: 'security', icon: Shield, label: 'Security & Auth' },
              { id: 'appearance', icon: Paintbrush, label: 'Appearance' },
            ].map(item => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                  activeTab === item.id 
                    ? 'bg-intern-blue/20 text-intern-blue' 
                    : 'text-muted-foreground hover:bg-secondary hover:text-foreground'
                }`}
              >
                <item.icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            ))}
          </nav>
          
          <button 
            onClick={handleLogout}
            className="w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium text-red-500 hover:bg-red-500/10 transition-colors mt-auto"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 p-8 overflow-y-auto">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-2xl font-bold text-foreground capitalize">{activeTab}</h3>
            <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors">
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="max-w-2xl">
            {activeTab === 'profile' && (
              <div className="space-y-6">
                <div className="flex items-center gap-6 pb-6 border-b border-border">
                  <div className="h-20 w-20 rounded-full bg-gradient-to-tr from-intern-blue to-purple-500 p-1">
                    <div className="w-full h-full bg-background rounded-full border-2 border-transparent flex items-center justify-center">
                       <User className="w-8 h-8 text-foreground" />
                    </div>
                  </div>
                  <div>
                    <h4 className="text-foreground font-medium mb-2">Profile Avatar</h4>
                    <div className="flex gap-3">
                      <Button variant="outline" className="h-8 text-xs border-border text-foreground">Upload new</Button>
                      <Button variant="ghost" className="h-8 text-xs text-red-500 hover:text-red-400 hover:bg-red-500/10">Remove</Button>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-muted-foreground">First Name</label>
                    <input type="text" defaultValue="Pritam" className="w-full bg-secondary border border-border rounded-lg px-4 py-2 text-foreground focus:outline-none focus:border-intern-blue focus:ring-1 focus:ring-intern-blue" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-muted-foreground">Last Name</label>
                    <input type="text" defaultValue="K." className="w-full bg-secondary border border-border rounded-lg px-4 py-2 text-foreground focus:outline-none focus:border-intern-blue focus:ring-1 focus:ring-intern-blue" />
                  </div>
                  <div className="space-y-2 col-span-2">
                    <label className="text-sm font-medium text-muted-foreground">Email</label>
                    <input type="email" disabled defaultValue="dibyajyotichakrabarty391@gmail.com" className="w-full bg-secondary/50 border border-border rounded-lg px-4 py-2 text-muted-foreground cursor-not-allowed" />
                  </div>
                  <div className="space-y-2 col-span-2">
                    <label className="text-sm font-medium text-muted-foreground">Bio</label>
                    <textarea rows={3} defaultValue="Frontend developer exploring the world of AI." className="w-full bg-secondary border border-border rounded-lg px-4 py-2 text-foreground focus:outline-none focus:border-intern-blue focus:ring-1 focus:ring-intern-blue resize-none" />
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'notifications' && (
              <div className="space-y-6">
                {[
                  { title: "Task Matches", desc: "Get notified when new tasks match your skills." },
                  { title: "Application Updates", desc: "Alerts when your task application is reviewed." },
                  { title: "Platform Announcements", desc: "Updates about InternLoop features." },
                  { title: "Wallet Alerts", desc: "Notifications for deposits and withdrawals." }
                ].map((item, i) => (
                  <div key={i} className="flex items-center justify-between p-4 rounded-xl border border-border bg-secondary">
                    <div>
                      <h4 className="text-foreground font-medium">{item.title}</h4>
                      <p className="text-sm text-muted-foreground">{item.desc}</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" defaultChecked className="sr-only peer" />
                      <div className="w-11 h-6 bg-border peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-intern-blue"></div>
                    </label>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'security' && (
              <div className="space-y-6">
                <div className="p-4 rounded-xl border border-border bg-secondary space-y-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="text-foreground font-medium flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-intern-success" /> Two-Factor Authentication</h4>
                      <p className="text-sm text-muted-foreground mt-1">Add an extra layer of security to your account.</p>
                    </div>
                    <Badge variant="outline" className="border-intern-success/30 text-intern-success bg-intern-success/10">Enabled</Badge>
                  </div>
                  <Button variant="outline" className="border-border text-foreground w-full sm:w-auto mt-2">Manage 2FA</Button>
                </div>

                <div className="p-4 rounded-xl border border-border bg-secondary space-y-4">
                  <div>
                    <h4 className="text-foreground font-medium">Active Sessions</h4>
                    <p className="text-sm text-muted-foreground mt-1">Review where you're logged in.</p>
                  </div>
                  <div className="flex items-center justify-between py-2 border-t border-border">
                    <div className="flex flex-col">
                      <span className="text-sm text-foreground">Mac OS • Chrome</span>
                      <span className="text-xs text-intern-success">Current session</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between py-2 border-t border-border">
                    <div className="flex flex-col">
                      <span className="text-sm text-foreground">iPhone 14 • Safari</span>
                      <span className="text-xs text-muted-foreground">Last active 2 hrs ago</span>
                    </div>
                    <Button variant="ghost" className="text-xs h-7 text-red-500 hover:bg-red-500/10">Revoke</Button>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'appearance' && (
              <ThemeSettingsTab />
            )}

            <div className="mt-8 pt-6 border-t border-border flex justify-end">
              <Button onClick={onClose} variant="ghost" className="mr-3 text-foreground hover:bg-secondary">Cancel</Button>
              <Button onClick={handleSave} className="bg-intern-blue text-white hover:bg-intern-blue/90 w-32">
                {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Save Changes'}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
