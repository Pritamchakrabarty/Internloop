import React, { useState, useEffect } from 'react';
import { X, Mail, Phone, KeyRound, Loader2, ShieldCheck, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

export default function AuthModal({ 
  isOpen, 
  onClose, 
  onSuccess,
  initialStep = 'login'
}: { 
  isOpen: boolean; 
  onClose: () => void; 
  onSuccess: () => void;
  initialStep?: 'login' | 'signup';
}) {
  const [step, setStep] = useState<'login' | 'signup' | 'forgot'>(initialStep);
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');

  // Reset state when closed or mode changed
  useEffect(() => {
    if (isOpen) {
      setStep(initialStep);
      const token = localStorage.getItem('auth_token');
      if (token) {
        onSuccess();
      }
    }
    if (!isOpen) {
      setStep(initialStep);
      setIdentifier('');
      setPassword('');
      setConfirmPassword('');
      setError('');
      setMessage('');
      setIsLoading(false);
    }
  }, [isOpen, onSuccess, initialStep]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!identifier) {
      setError('Please enter a valid email or phone number.');
      return;
    }

    if (step === 'signup' && password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    setIsLoading(true);
    setError('');
    setMessage('');

    try {
      let endpoint = '';
      let body: any = { identifier };
      
      if (step === 'login') {
        endpoint = '/api/auth/login';
        body.password = password;
      } else if (step === 'signup') {
        endpoint = '/api/auth/signup';
        body.password = password;
      } else if (step === 'forgot') {
        endpoint = '/api/auth/forgot-password';
      }

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      
      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        if (step === 'signup' && data.error === 'Account already exists, please login.') {
          setError(data.error);
          setTimeout(() => setStep('login'), 2000);
          return;
        }
        throw new Error(data.error || 'Request failed.');
      }

      if (step === 'forgot') {
        toast.success(data.message || 'Password reset instructions sent.');
        setStep('login');
      } else {
        if (data.token) {
          localStorage.setItem('auth_token', data.token);
          onSuccess();
        }
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-background border border-border rounded-2xl w-full max-w-md shadow-2xl overflow-hidden relative">
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b border-border">
          <div className="flex items-center gap-2 text-foreground font-semibold">
            <ShieldCheck className="w-5 h-5 text-intern-blue" />
            <span>{step === 'login' ? 'Login' : step === 'signup' ? 'Sign Up' : 'Forgot Password'}</span>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="text-center space-y-2 mb-6">
              <h3 className="text-xl font-bold text-foreground">
                {step === 'login' ? 'Welcome Back' : step === 'signup' ? 'Create Account' : 'Reset Password'}
              </h3>
              <p className="text-sm text-muted-foreground">
                {step === 'login' ? 'Sign in to your account.' : step === 'signup' ? 'Join InternLoop today.' : 'Enter your identifier to reset your password.'}
              </p>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground/80">Phone Number or Email</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <input
                    type="text"
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 bg-secondary/30 border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-intern-blue/50 focus:border-intern-blue/50 transition-all font-mono"
                    placeholder="name@example.com"
                    autoFocus
                    required
                  />
                </div>
              </div>

              {step !== 'forgot' && (
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground/80">Password</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <KeyRound className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 bg-secondary/30 border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-intern-blue/50 focus:border-intern-blue/50 transition-all font-mono"
                      placeholder="••••••••"
                      required
                    />
                  </div>
                </div>
              )}

              {step === 'signup' && (
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground/80">Confirm Password</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <KeyRound className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 bg-secondary/30 border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-intern-blue/50 focus:border-intern-blue/50 transition-all font-mono"
                      placeholder="••••••••"
                      required
                    />
                  </div>
                </div>
              )}
            </div>

            {error && <div className="p-3 bg-red-500/10 border border-red-500/20 text-red-500 text-sm rounded-lg flex items-start gap-2 text-left">{error}</div>}
            {message && <div className="p-3 bg-intern-blue/10 border border-intern-blue/20 text-intern-blue text-sm rounded-lg flex items-start gap-2 text-left">{message}</div>}

            <Button
              type="submit"
              disabled={isLoading}
              className="w-full h-12 bg-intern-blue hover:bg-intern-blue/90 text-white rounded-xl shadow-[0_0_20px_rgba(33,150,243,0.3)] hover:shadow-[0_0_30px_rgba(33,150,243,0.5)] transition-all font-semibold flex items-center justify-center space-x-2"
            >
              {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : (
                  <>
                    <span>{step === 'login' ? 'Login' : step === 'signup' ? 'Sign Up' : 'Reset Password'}</span>
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </>
              )}
            </Button>
            
            <div className="flex flex-col items-center gap-2 mt-4 text-sm text-muted-foreground">
              {step === 'login' ? (
                <>
                  <button type="button" onClick={() => setStep('forgot')} className="hover:text-intern-blue transition-colors">Forgot Password?</button>
                  <button type="button" onClick={() => setStep('signup')} className="hover:text-white transition-colors">Don't have an account? Sign up</button>
                </>
              ) : step === 'signup' ? (
                <button type="button" onClick={() => setStep('login')} className="hover:text-white transition-colors">Already have an account? Login</button>
              ) : (
                <button type="button" onClick={() => setStep('login')} className="hover:text-white transition-colors">Back to Login</button>
              )}
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
