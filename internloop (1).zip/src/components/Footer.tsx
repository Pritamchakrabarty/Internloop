import React from 'react';
import { Moon, Sun } from 'lucide-react';
import { useTheme } from './ThemeProvider';

interface FooterProps {
  onNavigate: (page: 'privacy' | 'terms' | 'refund' | 'manifesto' | 'how-it-works') => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  const { theme, setTheme } = useTheme();

  return (
    <footer className="w-full bg-background border-t border-border py-12 px-6 mt-16 z-10 relative">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="flex flex-col items-center md:items-start text-center md:text-left">
          <p className="text-foreground font-bold mb-2 flex items-center gap-4">
            © 2026 Internloop. All Rights Reserved
            <button 
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="p-2 rounded-full bg-secondary hover:bg-secondary/80 text-foreground transition-colors outline-none"
              aria-label="Toggle theme"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </p>
          <p className="text-muted-foreground text-sm">Nuagarh sahi, Daruthenga, Bhubaneswar, Odisha 751024</p>
          <p className="text-muted-foreground text-sm">Phone: +91 9827746174 | Email: dibyajyotichakrabarty391@gmail.com</p>
        </div>
        <div className="flex flex-wrap justify-center gap-6">
          <button 
            onClick={() => onNavigate('manifesto')}
            className="text-muted-foreground hover:text-white transition-colors text-sm font-semibold text-intern-sky"
          >
            Manifesto
          </button>
          <button 
            onClick={() => onNavigate('how-it-works')}
            className="text-muted-foreground hover:text-white transition-colors text-sm font-semibold text-intern-sky"
          >
            How it Works
          </button>
          <button 
            onClick={() => onNavigate('privacy')}
            className="text-muted-foreground hover:text-white transition-colors text-sm"
          >
            Privacy Policy
          </button>
          <button 
            onClick={() => onNavigate('terms')}
            className="text-muted-foreground hover:text-white transition-colors text-sm"
          >
            Terms & Conditions
          </button>
          <button 
            onClick={() => onNavigate('refund')}
            className="text-muted-foreground hover:text-white transition-colors text-sm"
          >
            Refund & Cancellation Policy
          </button>
        </div>
      </div>
    </footer>
  );
}
